// console.h - log compartilhado entre engine, scripts Lua e editor
#pragma once
#include <string>
#include <utility>
#include <vector>

struct Console {
    std::vector<std::pair<bool, std::string>> lines;   // (é_erro, texto)

    void log(const std::string& s) { push(false, s); }
    void error(const std::string& s) { push(true, s); }
    void clear() { lines.clear(); }

private:
    void push(bool err, const std::string& s) {
        lines.emplace_back(err, s);
        if (lines.size() > 500) lines.erase(lines.begin(), lines.begin() + 100);
    }
};
