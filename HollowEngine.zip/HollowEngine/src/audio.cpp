// audio.cpp - mixer por software: carrega WAV, converte para 44100 Hz / estéreo / 16 bits e soma as vozes no callback do SDL.
#include "audio.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <map>
#include <memory>
#include <vector>
#include "sdl_compat.h"
#include "vfs.h"

namespace Audio {
namespace {

constexpr int kRate = 44100;
constexpr int kChannels = 2;
constexpr int kMaxVoices = 32;

struct Sound {
    std::vector<int16_t> samples;   // intercalado L R
    size_t frames() const { return samples.size() / kChannels; }
};

struct Voice {
    int id = 0;
    const Sound* snd = nullptr;
    size_t pos = 0;   // em frames
    float volume = 1.0f, pan = 0.0f;
    bool loop = false;
    bool active = false;
};

SDL_AudioDeviceID g_dev = 0;
bool g_tried = false;
std::string g_initError;
float g_master = 1.0f;
int g_nextId = 1;
Voice g_voices[kMaxVoices];
std::map<std::string, std::unique_ptr<Sound>> g_cache;   // vive até shutdown(): as vozes apontam para cá
std::vector<float> g_acc;

struct Lock {   // trava o callback enquanto mexemos nas vozes
    Lock() { if (g_dev) SDL_LockAudioDevice(g_dev); }
    ~Lock() { if (g_dev) SDL_UnlockAudioDevice(g_dev); }
};

float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

void SDLCALL mixCallback(void*, Uint8* stream, int len) {
    const int frames = len / (int)(sizeof(int16_t) * kChannels);
    if ((int)g_acc.size() < frames * kChannels) g_acc.resize((size_t)frames * kChannels);
    std::fill(g_acc.begin(), g_acc.begin() + (size_t)frames * kChannels, 0.0f);

    for (Voice& v : g_voices) {
        if (!v.active || !v.snd) continue;
        const size_t total = v.snd->frames();
        if (total == 0) { v.active = false; continue; }
        const float gl = v.volume * (v.pan > 0 ? 1.0f - v.pan : 1.0f);
        const float gr = v.volume * (v.pan < 0 ? 1.0f + v.pan : 1.0f);
        const int16_t* src = v.snd->samples.data();
        for (int i = 0; i < frames; i++) {
            if (v.pos >= total) {
                if (!v.loop) { v.active = false; break; }
                v.pos = 0;
            }
            g_acc[(size_t)i * 2]     += src[v.pos * 2]     * gl;
            g_acc[(size_t)i * 2 + 1] += src[v.pos * 2 + 1] * gr;
            v.pos++;
        }
    }

    int16_t* out = reinterpret_cast<int16_t*>(stream);
    for (int i = 0; i < frames * kChannels; i++) {
        float s = g_acc[(size_t)i] * g_master;
        out[i] = (int16_t)clampf(s, -32768.0f, 32767.0f);
    }
}

// Lê o arquivo (pelo vfs: disco, SDL_RWops ou assets do APK) e converte para o formato do mixer.
Sound* loadSound(const std::string& path, std::string* error) {
    auto it = g_cache.find(path);
    if (it != g_cache.end()) return it->second.get();

    std::string data;
    if (!readFile(path, data) || data.empty()) { if (error) *error = "arquivo de áudio não encontrado: " + path; return nullptr; }

    SDL_AudioSpec spec;
    Uint8* buf = nullptr;
    Uint32 len = 0;
    SDL_RWops* rw = SDL_RWFromConstMem(data.data(), (int)data.size());
    if (!rw || !SDL_LoadWAV_RW(rw, 1, &spec, &buf, &len)) {
        if (error) *error = "não consegui ler '" + path + "' (só há suporte a .wav): " + SDL_GetError();
        return nullptr;
    }

    SDL_AudioCVT cvt;
    int r = SDL_BuildAudioCVT(&cvt, spec.format, spec.channels, spec.freq, AUDIO_S16SYS, kChannels, kRate);
    if (r < 0) {
        SDL_FreeWAV(buf);
        if (error) *error = "formato de áudio não suportado em '" + path + "': " + SDL_GetError();
        return nullptr;
    }

    auto snd = std::make_unique<Sound>();
    if (r == 0) {   // já está no formato do mixer
        snd->samples.resize(len / sizeof(int16_t));
        std::memcpy(snd->samples.data(), buf, snd->samples.size() * sizeof(int16_t));
    } else {
        cvt.len = (int)len;
        cvt.buf = (Uint8*)SDL_malloc((size_t)len * (size_t)cvt.len_mult);
        if (!cvt.buf) { SDL_FreeWAV(buf); if (error) *error = "sem memória para converter '" + path + "'"; return nullptr; }
        std::memcpy(cvt.buf, buf, len);
        if (SDL_ConvertAudio(&cvt) != 0) {
            SDL_free(cvt.buf);
            SDL_FreeWAV(buf);
            if (error) *error = "falha ao converter '" + path + "': " + SDL_GetError();
            return nullptr;
        }
        snd->samples.resize((size_t)cvt.len_cvt / sizeof(int16_t));
        std::memcpy(snd->samples.data(), cvt.buf, snd->samples.size() * sizeof(int16_t));
        SDL_free(cvt.buf);
    }
    SDL_FreeWAV(buf);

    if (snd->frames() == 0) { if (error) *error = "áudio vazio: " + path; return nullptr; }
    Sound* raw = snd.get();
    g_cache[path] = std::move(snd);
    return raw;
}

}  // namespace

bool init(std::string* error) {
    if (g_dev) return true;
    if (g_tried) { if (error) *error = g_initError; return false; }   // já falhou: não tenta (nem loga) de novo a cada som
    g_tried = true;

    if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0) {
        g_initError = std::string("áudio indisponível: ") + SDL_GetError();
        if (error) *error = g_initError;
        return false;
    }
    SDL_AudioSpec want;
    SDL_zero(want);
    want.freq = kRate;
    want.format = AUDIO_S16SYS;
    want.channels = kChannels;
    want.samples = 1024;
    want.callback = mixCallback;
    g_dev = SDL_OpenAudioDevice(nullptr, 0, &want, nullptr, 0);   // 0 = o SDL converte para o nosso formato se preciso
    if (!g_dev) {
        g_initError = std::string("não consegui abrir o dispositivo de áudio: ") + SDL_GetError();
        SDL_QuitSubSystem(SDL_INIT_AUDIO);
        if (error) *error = g_initError;
        return false;
    }
    g_acc.assign(4096 * kChannels, 0.0f);
    SDL_PauseAudioDevice(g_dev, 0);
    return true;
}

void shutdown() {
    if (g_dev) {
        SDL_CloseAudioDevice(g_dev);
        g_dev = 0;
        SDL_QuitSubSystem(SDL_INIT_AUDIO);
    }
    for (Voice& v : g_voices) v = Voice();
    g_cache.clear();
    g_tried = false;
    g_initError.clear();
}

bool available() { return g_dev != 0; }

void stopAll() {
    Lock lk;
    for (Voice& v : g_voices) v.active = false;
}

int play(const std::string& path, float volume, bool loop, float pan, std::string* error) {
    if (!init(error)) return 0;
    Sound* snd = loadSound(path, error);   // fora do lock: ler e converter pode demorar
    if (!snd) return 0;

    Lock lk;
    Voice* slot = nullptr;
    for (Voice& v : g_voices)
        if (!v.active) { slot = &v; break; }
    if (!slot) { if (error) *error = "muitos sons ao mesmo tempo (limite: 32)"; return 0; }
    slot->id = g_nextId++;
    if (g_nextId <= 0) g_nextId = 1;
    slot->snd = snd;
    slot->pos = 0;
    slot->volume = clampf(volume, 0.0f, 4.0f);
    slot->pan = clampf(pan, -1.0f, 1.0f);
    slot->loop = loop;
    slot->active = true;
    return slot->id;
}

static Voice* findVoice(int id) {   // chamar com o lock
    if (id <= 0) return nullptr;
    for (Voice& v : g_voices)
        if (v.active && v.id == id) return &v;
    return nullptr;
}

void stop(int voice) { Lock lk; if (Voice* v = findVoice(voice)) v->active = false; }
bool isPlaying(int voice) { Lock lk; return findVoice(voice) != nullptr; }
void setVolume(int voice, float volume) { Lock lk; if (Voice* v = findVoice(voice)) v->volume = clampf(volume, 0.0f, 4.0f); }
void setPan(int voice, float pan) { Lock lk; if (Voice* v = findVoice(voice)) v->pan = clampf(pan, -1.0f, 1.0f); }
void setMasterVolume(float volume) { Lock lk; g_master = clampf(volume, 0.0f, 1.0f); }
float masterVolume() { return g_master; }

}  // namespace Audio
