#include "scene.h"
#include "vfs.h"
#include <fstream>
#include <iomanip>
#include <locale>
#include <sstream>

// ---------------------------------------------------------------- consulta

Entity* Scene::find(int id) {
    if (id == 0) return nullptr;
    for (Entity& e : entities) if (e.id == id) return &e;
    return nullptr;
}

const Entity* Scene::find(int id) const {
    if (id == 0) return nullptr;
    for (const Entity& e : entities) if (e.id == id) return &e;
    return nullptr;
}

Entity* Scene::findByName(const std::string& name) {
    for (Entity& e : entities) if (e.name == name) return &e;
    return nullptr;
}

bool Scene::activeInHierarchy(const Entity& e) const {
    const Entity* cur = &e;
    for (int guard = 0; cur && guard < 64; guard++) {
        if (!cur->active) return false;
        if (cur->parent == 0) return true;
        cur = find(cur->parent);
    }
    return cur != nullptr;
}

Mat4 Scene::worldMatrix(const Entity& e) const {
    Mat4 m = e.t.matrix();
    const Entity* cur = &e;
    for (int guard = 0; cur->parent != 0 && guard < 64; guard++) {
        cur = find(cur->parent);
        if (!cur) break;
        m = cur->t.matrix() * m;
    }
    return m;
}

bool Scene::isDescendant(int id, int ancestor) const {
    const Entity* cur = find(id);
    for (int guard = 0; cur && cur->parent != 0 && guard < 64; guard++) {
        if (cur->parent == ancestor) return true;
        cur = find(cur->parent);
    }
    return false;
}

// ---------------------------------------------------------------- edição

Entity& Scene::create(const std::string& name, MeshType mesh, const Vec3& pos) {
    Entity e;
    e.id = nextId++;
    e.name = name;
    e.mesh = mesh;
    e.t.pos = pos;
    entities.push_back(e);
    return entities.back();
}

int Scene::duplicate(int id) {
    const Entity* src = find(id);
    if (!src) return 0;
    Entity copy = *src;
    copy.id = nextId++;
    copy.name += " (cópia)";
    entities.push_back(copy);
    return copy.id;
}

bool Scene::setParent(int id, int parentId) {
    Entity* e = find(id);
    if (!e || id == parentId) return false;
    if (parentId != 0 && (!find(parentId) || isDescendant(parentId, id))) return false;
    Vec3 worldPos = worldMatrix(*e).translation();
    e->parent = parentId;
    if (parentId != 0) {
        const Entity* p = find(parentId);
        e->t.pos = worldMatrix(*p).inverseAffine().point(worldPos);
    } else {
        e->t.pos = worldPos;
    }
    // Obs.: só a posição de mundo é preservada; rotação e escala continuam locais.
    return true;
}

void Scene::destroy(int id) {
    if (!find(id)) return;
    std::vector<int> doomed{id};
    for (size_t i = 0; i < doomed.size(); i++)
        for (const Entity& e : entities)
            if (e.parent == doomed[i]) doomed.push_back(e.id);
    entities.erase(std::remove_if(entities.begin(), entities.end(),
                                  [&](const Entity& e) {
                                      return std::find(doomed.begin(), doomed.end(), e.id) != doomed.end();
                                  }),
                   entities.end());
}

void Scene::flushDestroy() {
    std::vector<int> ids;
    ids.swap(pending);
    for (int id : ids) destroy(id);
}

bool Scene::overlaps(int a, int b) const {
    const Entity* ea = find(a);
    const Entity* eb = find(b);
    if (!ea || !eb) return false;
    auto bounds = [&](const Entity& e, Vec3& lo, Vec3& hi) {
        Mat4 w = worldMatrix(e);
        Vec3 h = meshHalfExtentsFor(e.mesh, e.model);
        lo = Vec3(1e30f, 1e30f, 1e30f);
        hi = Vec3(-1e30f, -1e30f, -1e30f);
        for (int i = 0; i < 8; i++) {
            Vec3 p = w.point(Vec3((i & 1) ? h.x : -h.x, (i & 2) ? h.y : -h.y, (i & 4) ? h.z : -h.z));
            for (int k = 0; k < 3; k++) { lo[k] = std::min(lo[k], p[k]); hi[k] = std::max(hi[k], p[k]); }
        }
    };
    Vec3 alo, ahi, blo, bhi;
    bounds(*ea, alo, ahi);
    bounds(*eb, blo, bhi);
    for (int k = 0; k < 3; k++)
        if (ahi[k] < blo[k] || bhi[k] < alo[k]) return false;
    return true;
}

void Scene::clear() {
    entities.clear();
    pending.clear();
    nextId = 1;
    camera = Camera();
    ambient = 0.35f;
    sky = 0xFFC896FF;
}

void Scene::setupDefault() {
    clear();
    camera.pos = Vec3(0, 4, 9);
    camera.yaw = -90;
    camera.pitch = -20;

    Entity& chao = create("Chão", MeshType::Plane);
    chao.t.scale = Vec3(14, 1, 14);
    chao.color = 0xFF6B8E5A;

    Entity& cubo = create("Cubo", MeshType::Cube, Vec3(0, 0.5f, 0));
    cubo.script = "scripts/girar.lua";

    Entity& esfera = create("Esfera", MeshType::Sphere, Vec3(3, 0.5f, 0));
    esfera.color = 0xFFE2724A;
    AnimClip flutuar;
    flutuar.name = "Flutuar";
    flutuar.duration = 2.0f;
    AnimTrack* tr = flutuar.track(AnimChannel::Position, true);
    tr->setKey(0.0f, Vec3(3, 0.5f, 0), Interp::Smooth);
    tr->setKey(1.0f, Vec3(3, 2.0f, 0), Interp::Smooth);
    tr->setKey(2.0f, Vec3(3, 0.5f, 0), Interp::Smooth);
    esfera.anim.clips.push_back(flutuar);
    esfera.anim.autoplay = "Flutuar";

    Entity& jogador = create("Jogador", MeshType::Cone, Vec3(-3, 0.5f, 0));
    jogador.color = 0xFFF2C94C;
    jogador.script = "scripts/jogador.lua";

    Entity& sol = create("Sol", MeshType::None, Vec3(0, 6, 0));
    sol.hasLight = true;
    sol.light.type = LightType::Directional;
    sol.light.intensity = 0.9f;
    sol.t.rot = Vec3(-50, 30, 0);
}

// ---------------------------------------------------------------- arquivo .hscene (texto)

static std::string oneLine(std::string s) {
    for (char& c : s) if (c == '\n' || c == '\r') c = ' ';
    return s;
}

static std::string restOfLine(std::istringstream& ss) {
    std::string r;
    std::getline(ss >> std::ws, r);
    while (!r.empty() && (r.back() == '\r' || r.back() == ' ')) r.pop_back();
    return r;
}

bool Scene::save(const std::string& path) const {
    std::ofstream f(path);
    if (!f) return false;
    f.imbue(std::locale::classic());
    f << std::setprecision(9);
    f << "hollow_scene 2\n";
    f << "ambient " << ambient << "\n";
    f << "sky " << sky << "\n";
    f << "camera " << camera.pos.x << " " << camera.pos.y << " " << camera.pos.z << " "
      << camera.yaw << " " << camera.pitch << " " << camera.fov << "\n";
    for (const Entity& e : entities) {
        f << "entity " << e.id << "\n";
        f << "name " << oneLine(e.name) << "\n";
        f << "parent " << e.parent << "\n";
        f << "active " << (e.active ? 1 : 0) << "\n";
        f << "transform " << e.t.pos.x << " " << e.t.pos.y << " " << e.t.pos.z << " "
          << e.t.rot.x << " " << e.t.rot.y << " " << e.t.rot.z << " "
          << e.t.scale.x << " " << e.t.scale.y << " " << e.t.scale.z << "\n";
        f << "mesh " << (int)e.mesh << "\n";
        f << "color " << e.color << "\n";
        if (!e.model.empty()) f << "model " << oneLine(e.model) << "\n";
        if (!e.texture.empty()) f << "texture " << oneLine(e.texture) << "\n";
        if (e.hasLight)
            f << "light " << (int)e.light.type << " " << e.light.intensity << " "
              << e.light.color.x << " " << e.light.color.y << " " << e.light.color.z << "\n";
        if (!e.script.empty()) f << "script " << oneLine(e.script) << "\n";
        if (!e.anim.autoplay.empty()) f << "autoplay " << oneLine(e.anim.autoplay) << "\n";
        f << "animspeed " << e.anim.speed << "\n";
        for (const AnimClip& c : e.anim.clips) {
            f << "clip " << (c.loop ? 1 : 0) << " " << c.duration << " " << oneLine(c.name) << "\n";
            for (const AnimTrack& tr : c.tracks) {
                f << "track " << (int)tr.channel << "\n";
                for (const Keyframe& k : tr.keys)
                    f << "key " << k.time << " " << k.value.x << " " << k.value.y << " " << k.value.z
                      << " " << (int)k.interp << "\n";
            }
        }
        f << "end\n";
    }
    return (bool)f;
}

bool Scene::load(const std::string& path) {
    std::string data;
    if (!readFile(path, data)) return false;
    std::istringstream f(data);
    f.imbue(std::locale::classic());

    Scene fresh;   // só substitui a cena atual se o arquivo tiver o cabeçalho certo
    std::string line;
    if (!std::getline(f, line) || line.rfind("hollow_scene", 0) != 0) return false;

    Entity* cur = nullptr;
    AnimClip* clip = nullptr;
    AnimTrack* track = nullptr;
    int maxId = 0;

    while (std::getline(f, line)) {
        std::istringstream ss(line);
        ss.imbue(std::locale::classic());
        std::string kw;
        if (!(ss >> kw)) continue;

        if (kw == "ambient") ss >> fresh.ambient;
        else if (kw == "sky") ss >> fresh.sky;
        else if (kw == "camera") {
            ss >> fresh.camera.pos.x >> fresh.camera.pos.y >> fresh.camera.pos.z
               >> fresh.camera.yaw >> fresh.camera.pitch >> fresh.camera.fov;
        } else if (kw == "entity") {
            fresh.entities.emplace_back();
            cur = &fresh.entities.back();
            clip = nullptr; track = nullptr;
            ss >> cur->id;
            maxId = std::max(maxId, cur->id);
        } else if (kw == "end") {
            cur = nullptr; clip = nullptr; track = nullptr;
        } else if (!cur) {
            continue;
        } else if (kw == "name") cur->name = restOfLine(ss);
        else if (kw == "parent") ss >> cur->parent;
        else if (kw == "active") { int a = 1; ss >> a; cur->active = a != 0; }
        else if (kw == "transform") {
            ss >> cur->t.pos.x >> cur->t.pos.y >> cur->t.pos.z >> cur->t.rot.x >> cur->t.rot.y
               >> cur->t.rot.z >> cur->t.scale.x >> cur->t.scale.y >> cur->t.scale.z;
        } else if (kw == "mesh") {
            int m = 0; ss >> m;
            cur->mesh = (m >= 0 && m < kMeshTypeCount) ? (MeshType)m : MeshType::Cube;
        } else if (kw == "color") ss >> cur->color;
        else if (kw == "texture") cur->texture = restOfLine(ss);
        else if (kw == "model") cur->model = restOfLine(ss);
        else if (kw == "light") {
            int type = 0;
            cur->hasLight = true;
            ss >> type >> cur->light.intensity >> cur->light.color.x >> cur->light.color.y >> cur->light.color.z;
            cur->light.type = type == 1 ? LightType::Directional : LightType::Point;
        } else if (kw == "script") cur->script = restOfLine(ss);
        else if (kw == "autoplay") cur->anim.autoplay = restOfLine(ss);
        else if (kw == "animspeed") ss >> cur->anim.speed;
        else if (kw == "clip") {
            int loop = 1;
            cur->anim.clips.emplace_back();
            clip = &cur->anim.clips.back();
            track = nullptr;
            ss >> loop >> clip->duration;
            clip->loop = loop != 0;
            clip->name = restOfLine(ss);
        } else if (kw == "track" && clip) {
            int ch = 0;
            ss >> ch;
            clip->tracks.emplace_back();
            track = &clip->tracks.back();
            track->channel = (AnimChannel)std::max(0, std::min(ch, 2));
        } else if (kw == "key" && track) {
            Keyframe k;
            int ip = 0;
            ss >> k.time >> k.value.x >> k.value.y >> k.value.z >> ip;
            k.interp = (Interp)std::max(0, std::min(ip, 2));
            track->keys.push_back(k);
        }
    }

    fresh.nextId = maxId + 1;
    // Pais inexistentes viram raiz (arquivo editado à mão, por exemplo)
    for (Entity& e : fresh.entities)
        if (e.parent != 0 && !fresh.find(e.parent)) e.parent = 0;
    *this = fresh;
    return true;
}
