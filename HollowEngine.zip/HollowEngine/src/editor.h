// editor.h - editor ImGui: hierarquia, inspetor, animação, console, gizmos e modo Play
#pragma once
#include <functional>
#include <string>
#include <vector>
#include "console.h"
#include "input.h"
#include "renderer.h"
#include "scene.h"
#include "script.h"

enum class PlayState { Stopped, Playing, Paused };
enum class GizmoMode { Move = 0, Scale = 1, Rotate = 2 };

// Navegador de arquivos em ImGui (substitui o zenity do código antigo; sem programas externos)
class FileBrowser {
public:
    void open(const char* title, const std::vector<std::string>& exts,
              std::function<void(const std::string&)> onPick);
    void draw();   // chamar todo frame, no nível raiz da UI

private:
    std::string title_ = "Selecionar arquivo";
    std::vector<std::string> exts_;
    std::function<void(const std::string&)> onPick_;
    char dir_[512] = ".";
    std::string selected_;
    bool wantOpen_ = false;
};

class Editor {
public:
    Editor(Renderer& r, Scene& s, ScriptSystem& sc, Input& in, Console& con);

    void ui();                  // monta os painéis ImGui
    void interact(float dt);    // câmera livre, seleção e gizmos
    void update(float dt);      // simulação (Play) e preview de animação
    void render();              // desenha o viewport

    PlayState state() const { return state_; }
    void newScene();
    void openStartScene();      // carrega scenes/cena.hscene ou cria a cena de exemplo

private:
    struct GizmoGeom {
        Vec3 origin;
        Vec3 axes[3];
        float len = 1;
    };

    // painéis
    void menuBar();
    void toolbarAndViewport();
    void hierarchyWindow();
    void drawNode(int id);
    void inspectorWindow();
    void animationWindow();
    void consoleWindow();

    // modo de jogo
    void play();
    void stop();

    // seleção / gizmos
    void select(int id);
    bool gizmoGeom(const View& v, GizmoGeom& g) const;
    int hitGizmo(const View& v, const Vec2& mouse) const;
    void dragGizmo(const View& v, const Vec2& delta);
    int pick(const View& v, const Vec2& mouse) const;
    uint32_t gizmoColor(int axis) const;

    // preview de animação no editor
    void previewApply(Entity& e, float t);
    void previewRestore();

    // arquivo
    void importModel(const std::string& path);
    void exportGame(const std::string& folder);
    bool saveScene(const std::string& path);
    bool loadScene(const std::string& path);

    Renderer& rend_;
    Scene& scene_;
    ScriptSystem& scripts_;
    Input& input_;
    Console& console_;

    Scene snapshot_;
    PlayState state_ = PlayState::Stopped;
    Camera editorCam_;
    int selected_ = 0;

    GizmoMode gizmoMode_ = GizmoMode::Move;
    int dragAxis_ = -1;
    int hoverAxis_ = -1;
    Vec2 lastMouse_;

    // viewport (preenchido por ui(), usado por interact()/render())
    Vec2 vpPos_, vpSize_;
    bool vpHovered_ = false, vpFocused_ = false;

    bool showHierarchy_ = true, showInspector_ = true, showAnim_ = true, showConsole_ = true;

    // ações adiadas para depois de percorrer a árvore (evita invalidar ponteiros)
    int pendingReparentChild_ = 0, pendingReparentParent_ = -1;
    int pendingDelete_ = 0, pendingDuplicate_ = 0;

    // animação
    int animClip_ = 0;
    float animTime_ = 0;
    bool previewPlaying_ = false;
    bool previewValid_ = false;
    int previewEntity_ = 0;
    Transform previewBase_;

    // arquivos
    FileBrowser browser_;
    char scenePath_[256] = "scenes/cena.hscene";
    char savePathBuf_[256] = "scenes/cena.hscene";
    bool wantSaveAs_ = false;
    bool wantExport_ = false;
    char exportPathBuf_[256] = "export/MeuJogo";
    float playTime_ = 0;
};
