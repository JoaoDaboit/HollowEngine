// camera.h - câmera e projeção em perspectiva
#pragma once
#include "math3d.h"

// Base da câmera pré-calculada para um viewport (evita recalcular trigonometria por vértice)
struct View {
    Vec3 pos, f, r, u;   // posição, frente, direita, cima
    float k = 1;         // h / (2 * tan(fov/2))  => pixels por unidade a profundidade 1
    float nearZ = 0.1f;
    int w = 1, h = 1;

    float depth(const Vec3& p) const { return (p - pos).dot(f); }

    bool project(const Vec3& p, Vec2& out) const {
        Vec3 d = p - pos;
        float z = d.dot(f);
        if (z < nearZ) return false;
        float s = k / z;
        out = {w * 0.5f + d.dot(r) * s, h * 0.5f - d.dot(u) * s};
        return true;
    }

    // Tamanho em unidades de mundo que ocupa 'px' pixels na posição p
    float worldUnitsForPixels(const Vec3& p, float px) const {
        float z = std::max(depth(p), nearZ);
        return px * z / k;
    }
};

struct Camera {
    Vec3 pos{0, 3, 6};
    float yaw = -90.0f, pitch = -25.0f;
    float fov = 45.0f;
    float nearPlane = 0.1f;

    Vec3 front() const {
        float cy = std::cos(radians(yaw)), sy = std::sin(radians(yaw));
        float cp = std::cos(radians(pitch)), sp = std::sin(radians(pitch));
        return Vec3(cy * cp, sp, sy * cp).normalized();
    }
    Vec3 right() const { return front().cross(Vec3(0, 1, 0)).normalized(); }
    Vec3 up() const { return right().cross(front()).normalized(); }

    View view(int w, int h) const {
        View v;
        v.pos = pos;
        v.f = front();
        v.r = v.f.cross(Vec3(0, 1, 0)).normalized();
        v.u = v.r.cross(v.f).normalized();
        v.w = std::max(w, 1);
        v.h = std::max(h, 1);
        v.k = v.h / (2.0f * std::tan(radians(fov) * 0.5f));
        v.nearZ = nearPlane;
        return v;
    }

    // Raio que passa pelo pixel (sx, sy) do viewport
    void ray(const Vec2& s, int w, int h, Vec3& origin, Vec3& dir) const {
        View v = view(w, h);
        origin = pos;
        dir = (v.f + v.r * ((s.x - v.w * 0.5f) / v.k) + v.u * ((v.h * 0.5f - s.y) / v.k)).normalized();
    }
};
