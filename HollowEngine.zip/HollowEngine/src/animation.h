// animation.h - clips de animação por keyframes (posição / rotação / escala)
#pragma once
#include <string>
#include <vector>
#include "math3d.h"

enum class AnimChannel : int { Position = 0, Rotation = 1, Scale = 2 };
enum class Interp : int { Linear = 0, Step = 1, Smooth = 2 };

extern const char* const kChannelNames[3];   // "Posição", "Rotação", "Escala"
extern const char* const kInterpNames[3];    // "Linear", "Degrau", "Suave"

struct Keyframe {
    float time = 0;
    Vec3 value;
    Interp interp = Interp::Linear;   // como interpolar DESTE keyframe até o próximo
};

struct AnimTrack {
    AnimChannel channel = AnimChannel::Position;
    std::vector<Keyframe> keys;   // sempre ordenado por tempo

    bool sample(float t, Vec3& out) const;
    void setKey(float t, const Vec3& v, Interp i = Interp::Linear);   // insere ou substitui
    void removeKey(int index);
    float lastTime() const { return keys.empty() ? 0.0f : keys.back().time; }
};

struct AnimClip {
    std::string name = "Clip";
    float duration = 1.0f;
    bool loop = true;
    std::vector<AnimTrack> tracks;

    AnimTrack* track(AnimChannel c, bool create);
    const AnimTrack* track(AnimChannel c) const;
    // Aplica as faixas do clip no tempo t sobre o transform
    void sample(float t, Transform& out) const;
    // Estende a duração para caber o último keyframe
    void fitDuration();
};

// Componente: guarda os clips do objeto e o estado de reprodução
struct Animator {
    std::vector<AnimClip> clips;
    int current = -1;
    float time = 0;
    float speed = 1.0f;
    bool playing = false;
    std::string autoplay;   // clip tocado automaticamente ao dar Play (vazio = nenhum)

    int find(const std::string& name) const;
    bool play(const std::string& name, bool restart = true);
    void stop() { playing = false; }
    void update(float dt, Transform& t);
};
