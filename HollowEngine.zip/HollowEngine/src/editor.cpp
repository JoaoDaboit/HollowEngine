#include "editor.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include "imgui/imgui.h"

namespace fs = std::filesystem;

// ---------------------------------------------------------------- utilidades

static const uint32_t kColX = 0xFFE04040, kColY = 0xFF40E040, kColZ = 0xFF4080FF, kColHot = 0xFFFFE040;

static void argbToFloat3(uint32_t c, float out[3]) {
    out[0] = ((c >> 16) & 0xFF) / 255.0f;
    out[1] = ((c >> 8) & 0xFF) / 255.0f;
    out[2] = (c & 0xFF) / 255.0f;
}

static uint32_t float3ToArgb(const float c[3]) {
    auto q = [](float v) { return (uint32_t)(std::max(0.0f, std::min(1.0f, v)) * 255.0f + 0.5f); };
    return 0xFF000000u | (q(c[0]) << 16) | (q(c[1]) << 8) | q(c[2]);
}

static float distPointSegment(const Vec2& p, const Vec2& a, const Vec2& b) {
    Vec2 ab = b - a;
    float l2 = ab.dot(ab);
    float t = l2 > 1e-6f ? std::max(0.0f, std::min(1.0f, (p - a).dot(ab) / l2)) : 0.0f;
    return (p - (a + ab * t)).length();
}

static void copyStr(char* dst, size_t n, const std::string& s) {
    std::strncpy(dst, s.c_str(), n - 1);
    dst[n - 1] = '\0';
}

// ---------------------------------------------------------------- FileBrowser

void FileBrowser::open(const char* title, const std::vector<std::string>& exts,
                       std::function<void(const std::string&)> onPick) {
    title_ = title;
    exts_ = exts;
    onPick_ = std::move(onPick);
    selected_.clear();
    wantOpen_ = true;
}

void FileBrowser::draw() {
    // OpenPopup precisa acontecer no mesmo nível de ID do BeginPopupModal, por isso o flag
    if (wantOpen_) { ImGui::OpenPopup(title_.c_str()); wantOpen_ = false; }
    ImGui::SetNextWindowSize(ImVec2(540, 400), ImGuiCond_Appearing);
    if (!ImGui::BeginPopupModal(title_.c_str(), nullptr, 0)) return;

    ImGui::InputText("Pasta", dir_, sizeof dir_);
    ImGui::SameLine();
    if (ImGui::Button("Subir")) {
        std::error_code ec;
        fs::path up = fs::weakly_canonical(fs::path(dir_), ec).parent_path();
        if (!up.empty()) copyStr(dir_, sizeof dir_, up.string());
    }

    ImGui::BeginChild("lista", ImVec2(0, -34), true);
    std::vector<fs::path> dirs, files;
    std::error_code ec;
    for (fs::directory_iterator it(fs::path(dir_), ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        if (it->is_directory(e2)) { dirs.push_back(it->path()); continue; }
        std::string ext = it->path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return (char)std::tolower(c); });
        if (exts_.empty() || std::find(exts_.begin(), exts_.end(), ext) != exts_.end()) files.push_back(it->path());
    }
    std::sort(dirs.begin(), dirs.end());
    std::sort(files.begin(), files.end());

    bool accept = false;
    for (const fs::path& d : dirs) {
        std::string label = "[pasta] " + d.filename().string();
        if (ImGui::Selectable(label.c_str())) { copyStr(dir_, sizeof dir_, d.string()); break; }
    }
    for (const fs::path& f : files) {
        std::string full = f.string();
        if (ImGui::Selectable(f.filename().string().c_str(), selected_ == full, ImGuiSelectableFlags_AllowDoubleClick)) {
            selected_ = full;
            if (ImGui::IsMouseDoubleClicked(0)) accept = true;
        }
    }
    ImGui::EndChild();

    ImGui::TextUnformatted(selected_.empty() ? "(nenhum arquivo selecionado)" : selected_.c_str());
    ImGui::SameLine(ImGui::GetWindowWidth() - 150);
    if (ImGui::Button("OK") && !selected_.empty()) accept = true;
    ImGui::SameLine();
    bool cancel = ImGui::Button("Cancelar");

    if (accept) {
        std::error_code e3;
        fs::path rel = fs::relative(fs::path(selected_), fs::current_path(), e3);   // prefere caminho relativo ao projeto
        std::string out = (!e3 && !rel.empty() && rel.string().rfind("..", 0) != 0) ? rel.string() : selected_;
        if (onPick_) onPick_(out);
        ImGui::CloseCurrentPopup();
    } else if (cancel) {
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- Editor: ciclo de vida

Editor::Editor(Renderer& r, Scene& s, ScriptSystem& sc, Input& in, Console& con)
    : rend_(r), scene_(s), scripts_(sc), input_(in), console_(con) {}

void Editor::newScene() {
    if (state_ != PlayState::Stopped) { console_.error("Pare o jogo antes de criar outra cena."); return; }
    previewRestore();
    scene_.clear();
    selected_ = 0;
    rend_.clearTextures();
}

void Editor::openStartScene() {
    if (scene_.load(scenePath_)) {
        console_.log(std::string("Cena carregada: ") + scenePath_);
    } else {
        scene_.setupDefault();
        console_.log("Cena de exemplo criada (salve em Arquivo > Salvar).");
    }
    editorCam_ = scene_.camera;
}

void Editor::importModel(const std::string& path) {
    const Mesh& m = meshFor(MeshType::Model, path);
    if (m.pos.empty()) { console_.error("Não foi possível importar: " + path); return; }
    std::string name = fs::path(path).stem().string();
    Vec3 p = editorCam_.pos + editorCam_.front() * 5.0f;
    Entity& e = scene_.create(name.empty() ? "Modelo" : name, MeshType::Model, p);
    e.model = path;
    e.t.scale = Vec3(2, 2, 2);   // o modelo chega normalizado em 1 unidade; 2 costuma ser um bom ponto de partida
    select(e.id);
    console_.log("Modelo importado: " + path + " (" + std::to_string(m.triCount()) + " triângulos)");
    if (m.triCount() > 20000)
        console_.log("Aviso: modelo pesado para o rasterizador por software; considere uma versão com menos triângulos.");
}

// Copia a cena e tudo que ela referencia (scripts, texturas, modelos) para <pasta>/data,
// no formato que o hollow_player (e o APK) esperam: data/game.hscene + arquivos com os mesmos caminhos relativos.
void Editor::exportGame(const std::string& folder) {
    if (state_ != PlayState::Stopped) { console_.error("Pare o jogo antes de exportar."); return; }
    previewRestore();
    std::error_code ec;
    fs::path root(folder), data = root / "data";
    fs::create_directories(data, ec);
    if (ec) { console_.error("Não foi possível criar a pasta: " + folder); return; }

    if (!scene_.save((data / "game.hscene").string())) { console_.error("Falha ao gravar game.hscene"); return; }

    int copied = 0, problems = 0;
    auto copyAsset = [&](const std::string& rel) {
        if (rel.empty()) return;
        fs::path src(rel);
        if (src.is_absolute() || rel.rfind("..", 0) == 0) {
            console_.error("Caminho fora do projeto não foi copiado: " + rel + " (mova o arquivo para dentro da pasta do projeto)");
            problems++;
            return;
        }
        if (!fs::exists(src)) { console_.error("Arquivo não encontrado: " + rel); problems++; return; }
        fs::path dst = data / src;
        std::error_code e2;
        fs::create_directories(dst.parent_path(), e2);
        fs::copy_file(src, dst, fs::copy_options::overwrite_existing, e2);
        if (e2) { console_.error("Falha ao copiar " + rel); problems++; } else copied++;
    };
    for (const Entity& e : scene_.entities) {
        copyAsset(e.script);
        copyAsset(e.texture);
        if (e.mesh == MeshType::Model) copyAsset(e.model);
    }

    // Se o player já foi compilado ao lado do editor, copia junto
    bool hasPlayer = false;
    for (const char* name : {"hollow_player", "hollow_player.exe"}) {
        if (fs::exists(name)) {
            fs::copy_file(name, root / name, fs::copy_options::overwrite_existing, ec);
            hasPlayer = true;
        }
    }
    console_.log("Jogo exportado em '" + folder + "' (" + std::to_string(copied) + " arquivo(s) de assets" +
                 (problems ? ", " + std::to_string(problems) + " problema(s)" : "") + ").");
    if (!hasPlayer) console_.log("Compile o player com 'make player' e copie hollow_player para a pasta (veja docs/EXPORT.md).");
}

bool Editor::saveScene(const std::string& path) {
    std::error_code ec;
    fs::path p(path);
    if (p.has_parent_path()) fs::create_directories(p.parent_path(), ec);
    bool ok = scene_.save(path);
    if (ok) { copyStr(scenePath_, sizeof scenePath_, path); console_.log("Cena salva: " + path); }
    else console_.error("Não foi possível salvar: " + path);
    return ok;
}

bool Editor::loadScene(const std::string& path) {
    if (state_ != PlayState::Stopped) { console_.error("Pare o jogo antes de abrir outra cena."); return false; }
    previewRestore();
    if (!scene_.load(path)) { console_.error("Não foi possível abrir: " + path); return false; }
    copyStr(scenePath_, sizeof scenePath_, path);
    selected_ = 0;
    rend_.clearTextures();
    console_.log("Cena aberta: " + path);
    return true;
}

void Editor::select(int id) {
    if (id == selected_) return;
    previewRestore();
    selected_ = id;
    animClip_ = 0;
    animTime_ = 0;
}

void Editor::play() {
    if (state_ == PlayState::Paused) { state_ = PlayState::Playing; return; }
    if (state_ != PlayState::Stopped) return;
    previewRestore();
    snapshot_ = scene_;
    state_ = PlayState::Playing;
    playTime_ = 0;
    for (Entity& e : scene_.entities)
        if (!e.anim.autoplay.empty()) e.anim.play(e.anim.autoplay);
    scripts_.start(&scene_, &input_, &console_);
    console_.log("Jogo iniciado.");
}

void Editor::stop() {
    if (state_ == PlayState::Stopped) return;
    scripts_.stop();
    scene_ = snapshot_;
    state_ = PlayState::Stopped;
    input_.enabled = false;
    if (!scene_.find(selected_)) selected_ = 0;
    console_.log("Jogo parado; cena restaurada.");
}

void Editor::update(float dt) {
    ImGuiIO& io = ImGui::GetIO();
    if (state_ == PlayState::Playing) {
        input_.enabled = (vpHovered_ || vpFocused_) && !io.WantTextInput;
        input_.mx = (int)(io.MousePos.x - vpPos_.x);
        input_.my = (int)(io.MousePos.y - vpPos_.y);
        input_.screenW = (int)vpSize_.x;
        input_.screenH = (int)vpSize_.y;
        playTime_ += dt;
        scripts_.update(dt);
        for (Entity& e : scene_.entities)
            if (scene_.activeInHierarchy(e)) e.anim.update(dt, e.t);
        scene_.flushDestroy();
    } else {
        input_.enabled = false;
        if (state_ == PlayState::Stopped && previewPlaying_) {
            Entity* e = scene_.find(selected_);
            if (!e || animClip_ < 0 || animClip_ >= (int)e->anim.clips.size()) { previewPlaying_ = false; return; }
            const AnimClip& c = e->anim.clips[animClip_];
            animTime_ += dt;
            if (animTime_ >= c.duration) {
                if (c.loop) animTime_ = std::fmod(animTime_, std::max(c.duration, 0.01f));
                else { animTime_ = c.duration; previewPlaying_ = false; }
            }
            previewApply(*e, animTime_);
        }
    }
}

// ---------------------------------------------------------------- preview de animação

void Editor::previewApply(Entity& e, float t) {
    if (animClip_ < 0 || animClip_ >= (int)e.anim.clips.size()) return;
    if (!previewValid_ || previewEntity_ != e.id) {
        previewBase_ = e.t;   // pose original, restaurável
        previewEntity_ = e.id;
        previewValid_ = true;
    }
    e.anim.clips[animClip_].sample(t, e.t);
}

void Editor::previewRestore() {
    if (previewValid_) {
        if (Entity* e = scene_.find(previewEntity_)) e->t = previewBase_;
    }
    previewValid_ = false;
    previewPlaying_ = false;
}

// ---------------------------------------------------------------- UI

void Editor::ui() {
    menuBar();
    toolbarAndViewport();
    if (showHierarchy_) hierarchyWindow();
    if (showInspector_) inspectorWindow();
    if (showAnim_) animationWindow();
    if (showConsole_) consoleWindow();
    browser_.draw();

    if (wantExport_) { ImGui::OpenPopup("Exportar jogo"); wantExport_ = false; }
    if (ImGui::BeginPopupModal("Exportar jogo", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("Pasta de destino (será criada/atualizada):");
        ImGui::InputText("##export", exportPathBuf_, sizeof exportPathBuf_);
        if (ImGui::Button("Exportar")) { exportGame(exportPathBuf_); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine();
        if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }

    if (wantSaveAs_) { ImGui::OpenPopup("Salvar cena como"); wantSaveAs_ = false; }
    if (ImGui::BeginPopupModal("Salvar cena como", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::InputText("Arquivo", savePathBuf_, sizeof savePathBuf_);
        if (ImGui::Button("Salvar")) { saveScene(savePathBuf_); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine();
        if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

void Editor::menuBar() {
    if (!ImGui::BeginMainMenuBar()) return;

    auto spawn = [&](const char* name, MeshType m, bool light, LightType lt) {
        Vec3 p = editorCam_.pos + editorCam_.front() * 5.0f;
        if (m != MeshType::None || light) p.y = std::max(p.y, 0.5f);
        Entity& e = scene_.create(name, m, p);
        if (light) {
            e.hasLight = true;
            e.light.type = lt;
            if (lt == LightType::Directional) e.t.rot = Vec3(-50, 30, 0);
        }
        select(e.id);
    };

    if (ImGui::BeginMenu("Arquivo")) {
        if (ImGui::MenuItem("Nova cena")) newScene();
        if (ImGui::MenuItem("Abrir...")) {
            browser_.open("Abrir cena", {".hscene"}, [this](const std::string& p) { loadScene(p); });
        }
        if (ImGui::MenuItem("Salvar")) saveScene(scenePath_);
        if (ImGui::MenuItem("Salvar como...")) { copyStr(savePathBuf_, sizeof savePathBuf_, scenePath_); wantSaveAs_ = true; }
        if (ImGui::MenuItem("Exportar jogo...")) wantExport_ = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Recarregar texturas e modelos")) { rend_.clearTextures(); clearModelCache(); }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Entidade")) {
        for (int i = 0; i < kMeshTypeCount; i++) {
            if ((MeshType)i == MeshType::Model) continue;   // modelos entram por "Importar modelo"
            std::string label = std::string(i == (int)MeshType::None ? "Objeto vazio" : kMeshNames[i]);
            if (ImGui::MenuItem(label.c_str())) spawn(kMeshNames[i], (MeshType)i, false, LightType::Point);
        }
        if (ImGui::MenuItem("Importar modelo (.obj)...")) {
            browser_.open("Importar modelo", {".obj"}, [this](const std::string& p) { importModel(p); });
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Luz pontual")) spawn("Luz pontual", MeshType::None, true, LightType::Point);
        if (ImGui::MenuItem("Luz direcional")) spawn("Luz direcional", MeshType::None, true, LightType::Directional);
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicar", nullptr, false, selected_ != 0)) pendingDuplicate_ = selected_;
        if (ImGui::MenuItem("Deletar", nullptr, false, selected_ != 0)) pendingDelete_ = selected_;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Janelas")) {
        ImGui::MenuItem("Hierarquia", nullptr, &showHierarchy_);
        ImGui::MenuItem("Inspetor", nullptr, &showInspector_);
        ImGui::MenuItem("Animação", nullptr, &showAnim_);
        ImGui::MenuItem("Console", nullptr, &showConsole_);
        ImGui::EndMenu();
    }
    ImGui::EndMainMenuBar();

    // ações pedidas pelo menu ou pela hierarquia (aplicadas aqui, fora de qualquer iteração)
    if (pendingDuplicate_) { int n = scene_.duplicate(pendingDuplicate_); if (n) select(n); pendingDuplicate_ = 0; }
    if (pendingDelete_) {
        if (pendingDelete_ == selected_) select(0);
        scene_.destroy(pendingDelete_);
        pendingDelete_ = 0;
    }
    if (pendingReparentChild_) {
        scene_.setParent(pendingReparentChild_, pendingReparentParent_ < 0 ? 0 : pendingReparentParent_);
        pendingReparentChild_ = 0;
    }
}

void Editor::toolbarAndViewport() {
    ImGui::SetNextWindowPos(ImVec2(250, 30), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(660, 520), ImGuiCond_FirstUseEver);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));   // o 3D é desenhado por baixo do ImGui
    bool open = ImGui::Begin("Viewport", nullptr, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleColor();
    if (!open) { vpSize_ = Vec2(); vpHovered_ = vpFocused_ = false; ImGui::End(); return; }

    if (state_ == PlayState::Playing) {
        if (ImGui::Button("Pausar")) state_ = PlayState::Paused;
    } else if (ImGui::Button(state_ == PlayState::Paused ? "Continuar" : "Play")) {
        play();
    }
    ImGui::SameLine();
    if (ImGui::Button("Parar")) stop();
    ImGui::SameLine();
    ImGui::TextDisabled("|");
    ImGui::SameLine();
    if (state_ == PlayState::Stopped) {
        const char* names[3] = {"Mover", "Escalar", "Rotacionar"};
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine();
            bool on = (int)gizmoMode_ == i;
            if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.45f, 0.80f, 1));
            if (ImGui::Button(names[i])) gizmoMode_ = (GizmoMode)i;
            if (on) ImGui::PopStyleColor();
        }
        ImGui::SameLine();
        if (ImGui::Button("Usar vista como câmera do jogo")) {
            scene_.camera.pos = editorCam_.pos;
            scene_.camera.yaw = editorCam_.yaw;
            scene_.camera.pitch = editorCam_.pitch;
        }
        ImGui::TextDisabled("Botão direito/Shift: olhar | WASD: mover | Space/Ctrl: subir/descer | Roda: zoom");
    } else {
        ImGui::TextDisabled("Jogando. Esc libera o mouse se um script o travou.");
    }

    ImVec2 avail = ImGui::GetContentRegionAvail();
    avail.x = std::max(avail.x, 8.0f);
    avail.y = std::max(avail.y, 8.0f);
    ImGui::InvisibleButton("canvas", avail, ImGuiButtonFlags_MouseButtonLeft | ImGuiButtonFlags_MouseButtonRight);
    vpHovered_ = ImGui::IsItemHovered();
    vpFocused_ = ImGui::IsWindowFocused();
    ImVec2 mn = ImGui::GetItemRectMin();
    ImVec2 sz = ImGui::GetItemRectSize();
    vpPos_ = Vec2(mn.x, mn.y);
    vpSize_ = Vec2(sz.x, sz.y);
    ImGui::End();
}

void Editor::hierarchyWindow() {
    ImGui::SetNextWindowPos(ImVec2(10, 30), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(230, 340), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Hierarquia", &showHierarchy_)) {
        std::vector<int> roots;
        for (const Entity& e : scene_.entities)
            if (e.parent == 0 || !scene_.find(e.parent)) roots.push_back(e.id);
        for (int id : roots) drawNode(id);

        ImGui::InvisibleButton("##soltar_raiz", ImVec2(-1, 40));   // solte aqui para remover o pai
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* p = ImGui::AcceptDragDropPayload("ENTIDADE")) {
                pendingReparentChild_ = *(const int*)p->Data;
                pendingReparentParent_ = 0;
            }
            ImGui::EndDragDropTarget();
        }
        if (ImGui::IsWindowFocused() && selected_ && !ImGui::GetIO().WantTextInput &&
            ImGui::IsKeyPressed(ImGuiKey_Delete))
            pendingDelete_ = selected_;
    }
    ImGui::End();
}

void Editor::drawNode(int id) {
    const Entity* e = scene_.find(id);
    if (!e) return;
    std::string label = e->name + "###ent" + std::to_string(id);
    std::vector<int> kids;
    for (const Entity& c : scene_.entities) if (c.parent == id) kids.push_back(c.id);

    ImGuiTreeNodeFlags fl = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth |
                            ImGuiTreeNodeFlags_DefaultOpen;
    if (kids.empty()) fl |= ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
    if (selected_ == id) fl |= ImGuiTreeNodeFlags_Selected;

    bool open = ImGui::TreeNodeEx(label.c_str(), fl);
    if (ImGui::IsItemClicked()) select(id);

    if (ImGui::BeginDragDropSource()) {
        ImGui::SetDragDropPayload("ENTIDADE", &id, sizeof(int));
        ImGui::TextUnformatted(e->name.c_str());
        ImGui::EndDragDropSource();
    }
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* p = ImGui::AcceptDragDropPayload("ENTIDADE")) {
            pendingReparentChild_ = *(const int*)p->Data;
            pendingReparentParent_ = id;
        }
        ImGui::EndDragDropTarget();
    }
    if (ImGui::BeginPopupContextItem()) {
        if (ImGui::MenuItem("Duplicar")) pendingDuplicate_ = id;
        if (ImGui::MenuItem("Deletar")) pendingDelete_ = id;
        ImGui::EndPopup();
    }
    if (!kids.empty() && open) {
        for (int k : kids) drawNode(k);
        ImGui::TreePop();
    }
}

void Editor::inspectorWindow() {
    ImGui::SetNextWindowPos(ImVec2(920, 30), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(330, 560), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Inspetor", &showInspector_)) { ImGui::End(); return; }

    Entity* e = scene_.find(selected_);
    if (!e) {
        ImGui::TextWrapped("Selecione um objeto na Hierarquia ou clique nele no Viewport.");
        ImGui::End();
        return;
    }
    const int id = e->id;

    char buf[256];
    copyStr(buf, sizeof buf, e->name);
    if (ImGui::InputText("Nome", buf, sizeof buf)) e->name = buf;
    ImGui::Checkbox("Ativo", &e->active);
    if (const Entity* p = scene_.find(e->parent)) ImGui::TextDisabled("Pai: %s", p->name.c_str());

    if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::DragFloat3("Posição", &e->t.pos.x, 0.05f);
        ImGui::DragFloat3("Rotação", &e->t.rot.x, 0.5f);
        ImGui::DragFloat3("Escala", &e->t.scale.x, 0.02f);
    }

    if (ImGui::CollapsingHeader("Malha e material", ImGuiTreeNodeFlags_DefaultOpen)) {
        int m = (int)e->mesh;
        if (ImGui::Combo("Malha", &m, kMeshNames, kMeshTypeCount)) e->mesh = (MeshType)m;
        if (e->mesh == MeshType::Model) {
            copyStr(buf, sizeof buf, e->model);
            if (ImGui::InputText("Modelo .obj", buf, sizeof buf)) e->model = buf;
            ImGui::SameLine();
            if (ImGui::Button("...##obj")) {
                browser_.open("Selecionar modelo", {".obj"}, [this, id](const std::string& p) {
                    if (Entity* en = scene_.find(id)) en->model = p;
                });
            }
            if (!e->model.empty() && meshFor(e->mesh, e->model).pos.empty())
                ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "Não foi possível carregar este modelo.");
        }
        if (e->mesh != MeshType::None) {
            float c[3];
            argbToFloat3(e->color, c);
            if (ImGui::ColorEdit3("Cor", c)) e->color = float3ToArgb(c);

            copyStr(buf, sizeof buf, e->texture);
            if (ImGui::InputText("Textura", buf, sizeof buf)) e->texture = buf;
            ImGui::SameLine();
            if (ImGui::Button("...##tex")) {
                browser_.open("Selecionar textura", {".png", ".jpg", ".jpeg"}, [this, id](const std::string& p) {
                    if (Entity* en = scene_.find(id)) en->texture = p;
                });
            }
            if (!e->texture.empty() && ImGui::Button("Remover textura")) e->texture.clear();
        }
    }

    if (ImGui::CollapsingHeader("Luz")) {
        ImGui::Checkbox("Tem luz", &e->hasLight);
        if (e->hasLight) {
            int t = (int)e->light.type;
            const char* tipos[2] = {"Pontual", "Direcional"};
            if (ImGui::Combo("Tipo", &t, tipos, 2)) e->light.type = (LightType)t;
            ImGui::DragFloat("Intensidade", &e->light.intensity, 0.01f, 0.0f, 10.0f);
            ImGui::ColorEdit3("Cor da luz", &e->light.color.x);
            if (e->light.type == LightType::Directional)
                ImGui::TextDisabled("A direção é a frente (-Z) do objeto; gire para apontar.");
        }
        ImGui::DragFloat("Luz ambiente (cena)", &scene_.ambient, 0.01f, 0.0f, 1.0f);
    }

    if (ImGui::CollapsingHeader("Script (Lua)", ImGuiTreeNodeFlags_DefaultOpen)) {
        copyStr(buf, sizeof buf, e->script);
        if (ImGui::InputText("Arquivo", buf, sizeof buf)) e->script = buf;
        ImGui::SameLine();
        if (ImGui::Button("...##lua")) {
            browser_.open("Selecionar script", {".lua"}, [this, id](const std::string& p) {
                if (Entity* en = scene_.find(id)) en->script = p;
            });
        }
        if (ImGui::Button("Criar novo script")) {
            std::string base;
            for (char ch : e->name) base += std::isalnum((unsigned char)ch) ? (char)std::tolower((unsigned char)ch) : '_';
            if (base.empty()) base = "script";
            std::string path = "scripts/" + base + ".lua";
            std::error_code ec;
            fs::create_directories("scripts", ec);
            if (!fs::exists(path)) {
                std::ofstream f(path);
                f << "-- Script do objeto \"" << e->name << "\"\n"
                  << "-- Callbacks opcionais: on_start(self) e on_update(self, dt)\n\n"
                  << "function on_start(self)\n  log(\"pronto: \" .. self:name())\nend\n\n"
                  << "function on_update(self, dt)\n  -- self:rotate(0, 90 * dt, 0)\nend\n";
            }
            e->script = path;
            console_.log("Script: " + path);
        }
        if (!e->script.empty()) { ImGui::SameLine(); if (ImGui::Button("Remover##lua")) e->script.clear(); }
        ImGui::TextDisabled("Scripts rodam ao apertar Play. Edite o .lua em qualquer editor de texto.");
    }

    if (ImGui::CollapsingHeader("Animator")) {
        ImGui::Text("Clips: %d", (int)e->anim.clips.size());
        std::string cur = e->anim.autoplay.empty() ? "(nenhum)" : e->anim.autoplay;
        if (ImGui::BeginCombo("Tocar ao iniciar", cur.c_str())) {
            if (ImGui::Selectable("(nenhum)", e->anim.autoplay.empty())) e->anim.autoplay.clear();
            for (const AnimClip& c : e->anim.clips)
                if (ImGui::Selectable(c.name.c_str(), c.name == e->anim.autoplay)) e->anim.autoplay = c.name;
            ImGui::EndCombo();
        }
        ImGui::DragFloat("Velocidade", &e->anim.speed, 0.01f, 0.0f, 10.0f);
        if (ImGui::Button("Abrir janela de animação")) showAnim_ = true;
    }
    ImGui::End();
}

void Editor::animationWindow() {
    ImGui::SetNextWindowPos(ImVec2(250, 560), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(660, 180), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Animação", &showAnim_)) { ImGui::End(); return; }

    Entity* e = scene_.find(selected_);
    if (!e) { ImGui::TextWrapped("Selecione um objeto para editar suas animações."); ImGui::End(); return; }
    if (state_ != PlayState::Stopped) {
        ImGui::TextWrapped("Pare o jogo para editar animações.");
        ImGui::End();
        return;
    }
    Animator& an = e->anim;

    if (ImGui::Button("Novo clip")) {
        AnimClip c;
        c.name = "Clip " + std::to_string(an.clips.size() + 1);
        an.clips.push_back(c);
        animClip_ = (int)an.clips.size() - 1;
        animTime_ = 0;
    }
    if (an.clips.empty()) { ImGui::SameLine(); ImGui::TextDisabled("Este objeto ainda não tem clips."); ImGui::End(); return; }
    animClip_ = std::max(0, std::min(animClip_, (int)an.clips.size() - 1));

    ImGui::SameLine();
    ImGui::SetNextItemWidth(160);
    if (ImGui::BeginCombo("##clip", an.clips[animClip_].name.c_str())) {
        for (int i = 0; i < (int)an.clips.size(); i++)
            if (ImGui::Selectable((an.clips[i].name + "##c" + std::to_string(i)).c_str(), i == animClip_)) {
                previewRestore();
                animClip_ = i;
                animTime_ = 0;
            }
        ImGui::EndCombo();
    }
    AnimClip& clip = an.clips[animClip_];

    ImGui::SameLine();
    if (ImGui::Button("Remover clip")) {
        previewRestore();
        if (an.autoplay == clip.name) an.autoplay.clear();
        an.clips.erase(an.clips.begin() + animClip_);
        animClip_ = 0;
        ImGui::End();
        return;
    }

    char nm[128];
    copyStr(nm, sizeof nm, clip.name);
    ImGui::SetNextItemWidth(160);
    if (ImGui::InputText("Nome##clip", nm, sizeof nm)) {
        if (an.autoplay == clip.name) an.autoplay = nm;
        clip.name = nm;
    }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(90);
    ImGui::DragFloat("Duração", &clip.duration, 0.05f, 0.05f, 600.0f, "%.2fs");
    ImGui::SameLine();
    ImGui::Checkbox("Loop", &clip.loop);
    animTime_ = std::max(0.0f, std::min(animTime_, clip.duration));

    // --- controles de preview
    if (ImGui::Button(previewPlaying_ ? "Pausar preview" : "Preview")) {
        previewPlaying_ = !previewPlaying_;
        if (previewPlaying_ && animTime_ >= clip.duration) animTime_ = 0;
    }
    ImGui::SameLine();
    if (ImGui::Button("Restaurar pose")) previewRestore();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(200);
    if (ImGui::SliderFloat("Tempo", &animTime_, 0.0f, clip.duration, "%.2fs")) {
        previewPlaying_ = false;
        previewApply(*e, animTime_);
    }

    // --- gravação de keyframes com a pose atual do objeto
    auto rec = [&](AnimChannel ch, const Vec3& v) {
        clip.track(ch, true)->setKey(animTime_, v);
        clip.fitDuration();
    };
    ImGui::TextUnformatted("Gravar keyframe no tempo atual:");
    ImGui::SameLine();
    if (ImGui::Button("Posição")) rec(AnimChannel::Position, e->t.pos);
    ImGui::SameLine();
    if (ImGui::Button("Rotação")) rec(AnimChannel::Rotation, e->t.rot);
    ImGui::SameLine();
    if (ImGui::Button("Escala")) rec(AnimChannel::Scale, e->t.scale);
    ImGui::SameLine();
    if (ImGui::Button("Tudo")) {
        rec(AnimChannel::Position, e->t.pos);
        rec(AnimChannel::Rotation, e->t.rot);
        rec(AnimChannel::Scale, e->t.scale);
    }

    // --- timeline
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    const float labelW = 70, rowH = 22, headH = 18;
    float w = std::max(260.0f, ImGui::GetContentRegionAvail().x);
    float x0 = p0.x + labelW, x1 = p0.x + w - 10;
    float dur = std::max(clip.duration, 0.01f);
    auto tx = [&](float t) { return x0 + t / dur * (x1 - x0); };
    float totalH = headH + rowH * 3;

    ImGui::InvisibleButton("timeline", ImVec2(w, totalH + 4));
    dl->AddRectFilled(p0, ImVec2(p0.x + w, p0.y + totalH), IM_COL32(28, 28, 38, 255));
    for (int s = 0; s <= (int)dur; s++) {
        char tl[16];
        std::snprintf(tl, sizeof tl, "%ds", s);
        dl->AddLine(ImVec2(tx((float)s), p0.y), ImVec2(tx((float)s), p0.y + totalH), IM_COL32(70, 70, 90, 255));
        dl->AddText(ImVec2(tx((float)s) + 3, p0.y + 1), IM_COL32(180, 180, 200, 255), tl);
    }
    for (int ch = 0; ch < 3; ch++) {
        float y = p0.y + headH + ch * rowH;
        dl->AddText(ImVec2(p0.x + 4, y + 4), IM_COL32(220, 220, 230, 255), kChannelNames[ch]);
        dl->AddLine(ImVec2(p0.x, y), ImVec2(p0.x + w, y), IM_COL32(60, 60, 80, 255));
        if (const AnimTrack* tr = clip.track((AnimChannel)ch)) {
            for (const Keyframe& k : tr->keys) {
                float cx = tx(k.time), cy = y + rowH * 0.5f;
                bool atCursor = std::fabs(k.time - animTime_) < 1e-3f;
                ImU32 col = atCursor ? IM_COL32(255, 220, 60, 255) : IM_COL32(120, 190, 255, 255);
                dl->AddQuadFilled(ImVec2(cx, cy - 6), ImVec2(cx + 6, cy), ImVec2(cx, cy + 6), ImVec2(cx - 6, cy), col);
            }
        }
    }
    dl->AddLine(ImVec2(tx(animTime_), p0.y), ImVec2(tx(animTime_), p0.y + totalH), IM_COL32(255, 80, 80, 255), 2.0f);
    if (ImGui::IsItemActive()) {   // arrastar no timeline = scrub
        float t = (ImGui::GetIO().MousePos.x - x0) / (x1 - x0) * dur;
        animTime_ = std::max(0.0f, std::min(t, clip.duration));
        previewPlaying_ = false;
        previewApply(*e, animTime_);
    }

    // --- lista editável de keyframes
    if (ImGui::TreeNode("Keyframes")) {
        for (AnimTrack& tr : clip.tracks) {
            ImGui::PushID((int)tr.channel);
            if (ImGui::TreeNodeEx(kChannelNames[(int)tr.channel], ImGuiTreeNodeFlags_DefaultOpen)) {
                int del = -1;
                for (int i = 0; i < (int)tr.keys.size(); i++) {
                    Keyframe& k = tr.keys[i];
                    ImGui::PushID(i);
                    ImGui::SetNextItemWidth(60);
                    ImGui::DragFloat("##t", &k.time, 0.01f, 0.0f, 600.0f, "%.2fs");
                    ImGui::SameLine();
                    ImGui::SetNextItemWidth(190);
                    ImGui::DragFloat3("##v", &k.value.x, 0.05f);
                    ImGui::SameLine();
                    int ip = (int)k.interp;
                    ImGui::SetNextItemWidth(80);
                    if (ImGui::Combo("##i", &ip, kInterpNames, 3)) k.interp = (Interp)ip;
                    ImGui::SameLine();
                    if (ImGui::SmallButton("X")) del = i;
                    ImGui::PopID();
                }
                if (del >= 0) tr.removeKey(del);
                std::sort(tr.keys.begin(), tr.keys.end(),
                          [](const Keyframe& a, const Keyframe& b) { return a.time < b.time; });
                ImGui::TreePop();
            }
            ImGui::PopID();
        }
        clip.fitDuration();
        ImGui::TreePop();
    }
    ImGui::End();
}

void Editor::consoleWindow() {
    ImGui::SetNextWindowPos(ImVec2(10, 380), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(230, 200), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Console", &showConsole_)) {
        if (ImGui::Button("Limpar")) console_.clear();
        ImGui::BeginChild("linhas", ImVec2(0, 0), true);
        for (const auto& l : console_.lines) {
            if (l.first) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.45f, 0.45f, 1));
            ImGui::TextWrapped("%s", l.second.c_str());
            if (l.first) ImGui::PopStyleColor();
        }
        if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 4) ImGui::SetScrollHereY(1.0f);
        ImGui::EndChild();
    }
    ImGui::End();
}

// ---------------------------------------------------------------- gizmos e seleção

bool Editor::gizmoGeom(const View& v, GizmoGeom& g) const {
    const Entity* e = scene_.find(selected_);
    if (!e) return false;
    Mat4 W = scene_.worldMatrix(*e);
    g.origin = W.translation();
    for (int i = 0; i < 3; i++) {
        Vec3 unit(i == 0 ? 1.0f : 0.0f, i == 1 ? 1.0f : 0.0f, i == 2 ? 1.0f : 0.0f);
        // escala usa os eixos locais do objeto; mover e rotacionar usam os eixos do mundo
        g.axes[i] = gizmoMode_ == GizmoMode::Scale ? W.axis(i).normalized() : unit;
    }
    g.len = std::max(0.05f, v.worldUnitsForPixels(g.origin, 80.0f));
    return true;
}

uint32_t Editor::gizmoColor(int axis) const {
    if (axis == dragAxis_ || (dragAxis_ < 0 && axis == hoverAxis_)) return kColHot;
    return axis == 0 ? kColX : (axis == 1 ? kColY : kColZ);
}

// Retorna o eixo (0..2) sob o mouse, ou -1
int Editor::hitGizmo(const View& v, const Vec2& mouse) const {
    GizmoGeom g;
    if (!gizmoGeom(v, g)) return -1;
    float best = 10.0f;   // tolerância em pixels
    int hit = -1;
    for (int i = 0; i < 3; i++) {
        float d = 1e30f;
        if (gizmoMode_ == GizmoMode::Rotate) {
            static const float radius[3] = {0.55f, 0.95f, 0.75f};
            Vec3 u = g.axes[(i + 1) % 3], w = g.axes[(i + 2) % 3];
            Vec2 prev;
            bool havePrev = false;
            for (int s = 0; s <= 48; s++) {
                float a = (float)s / 48 * 2.0f * kPi;
                Vec2 cur;
                bool ok = v.project(g.origin + u * (std::cos(a) * g.len * radius[i]) +
                                        w * (std::sin(a) * g.len * radius[i]), cur);
                if (ok && havePrev) d = std::min(d, distPointSegment(mouse, prev, cur));
                prev = cur;
                havePrev = ok;
            }
        } else {
            Vec2 a, b;
            if (v.project(g.origin, a) && v.project(g.origin + g.axes[i] * g.len, b))
                d = distPointSegment(mouse, a, b);
        }
        if (d < best) { best = d; hit = i; }
    }
    return hit;
}

void Editor::dragGizmo(const View& v, const Vec2& delta) {
    Entity* e = scene_.find(selected_);
    GizmoGeom g;
    if (!e || !gizmoGeom(v, g) || dragAxis_ < 0) { dragAxis_ = -1; return; }
    int a = dragAxis_;

    if (gizmoMode_ == GizmoMode::Rotate) {
        float d = (delta.x - delta.y) * 0.4f;
        e->t.rot[a] += (a == 1 ? 1.0f : -1.0f) * d;
        return;
    }

    // Converte o movimento do mouse em unidades de mundo ao longo do eixo (exato, independe da distância)
    Vec2 p0, p1;
    if (!v.project(g.origin, p0) || !v.project(g.origin + g.axes[a] * g.len, p1)) return;
    Vec2 s = p1 - p0;
    float sl = s.length();
    if (sl < 1e-3f) return;
    float amount = delta.dot(s * (1.0f / sl)) / (sl / g.len);

    if (gizmoMode_ == GizmoMode::Move) {
        Vec3 d = g.axes[a] * amount;
        if (const Entity* p = scene_.find(e->parent))
            d = scene_.worldMatrix(*p).inverseAffine().dir(d);   // mundo -> espaço do pai
        e->t.pos += d;
    } else {
        e->t.scale[a] = std::max(0.05f, e->t.scale[a] + amount);
    }
}

int Editor::pick(const View& v, const Vec2& mouse) const {
    // 1) marcadores (luzes e objetos vazios) têm prioridade: são pequenos
    int best = 0;
    float bestD = 14.0f;
    for (const Entity& e : scene_.entities) {
        if (e.mesh != MeshType::None || !scene_.activeInHierarchy(e)) continue;
        Vec2 s;
        if (!v.project(scene_.worldMatrix(e).translation(), s)) continue;
        float d = (s - mouse).length();
        if (d < bestD) { bestD = d; best = e.id; }
    }
    if (best) return best;

    // 2) raio contra a caixa de cada malha (no espaço local, funciona com rotação e escala)
    Vec3 o, dir;
    editorCam_.ray(mouse, v.w, v.h, o, dir);
    float bestT = 1e30f;
    for (const Entity& e : scene_.entities) {
        if (e.mesh == MeshType::None || !scene_.activeInHierarchy(e)) continue;
        Mat4 inv = scene_.worldMatrix(e).inverseAffine();
        float t;
        if (rayBox(inv.point(o), inv.dir(dir), meshHalfExtentsFor(e.mesh, e.model), t) && t < bestT) {
            bestT = t;
            best = e.id;
        }
    }
    return best;
}

// ---------------------------------------------------------------- interação no viewport

void Editor::interact(float dt) {
    if (state_ != PlayState::Stopped || vpSize_.x < 8 || vpSize_.y < 8) { dragAxis_ = -1; hoverAxis_ = -1; return; }
    ImGuiIO& io = ImGui::GetIO();
    const bool typing = io.WantTextInput;

    // câmera livre
    if (vpHovered_ && !typing) {
        bool look = io.MouseDown[1] || io.KeyShift;
        if (look && dragAxis_ < 0) {
            editorCam_.yaw += io.MouseDelta.x * 0.3f;
            editorCam_.pitch = std::max(-89.0f, std::min(89.0f, editorCam_.pitch - io.MouseDelta.y * 0.3f));
        }
        float speed = 6.0f * dt;
        Vec3 f = editorCam_.front(), r = editorCam_.right();
        if (ImGui::IsKeyDown(ImGuiKey_W)) editorCam_.pos += f * speed;
        if (ImGui::IsKeyDown(ImGuiKey_S)) editorCam_.pos += f * -speed;
        if (ImGui::IsKeyDown(ImGuiKey_D)) editorCam_.pos += r * speed;
        if (ImGui::IsKeyDown(ImGuiKey_A)) editorCam_.pos += r * -speed;
        if (ImGui::IsKeyDown(ImGuiKey_Space)) editorCam_.pos += Vec3(0, speed, 0);
        if (io.KeyCtrl) editorCam_.pos += Vec3(0, -speed, 0);
        if (io.MouseWheel != 0) editorCam_.pos += f * (io.MouseWheel * 1.0f);
    }

    View v = editorCam_.view((int)vpSize_.x, (int)vpSize_.y);
    Vec2 mouse(io.MousePos.x - vpPos_.x, io.MousePos.y - vpPos_.y);

    if (dragAxis_ >= 0) {
        if (!io.MouseDown[0]) dragAxis_ = -1;
        else dragGizmo(v, mouse - lastMouse_);
        lastMouse_ = mouse;
        return;
    }

    hoverAxis_ = (vpHovered_ && !io.KeyShift && !io.MouseDown[1]) ? hitGizmo(v, mouse) : -1;
    if (vpHovered_ && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !io.KeyShift) {
        if (hoverAxis_ >= 0) {
            dragAxis_ = hoverAxis_;
            lastMouse_ = mouse;
        } else {
            select(pick(v, mouse));
        }
    }
}

// ---------------------------------------------------------------- desenho do viewport

void Editor::render() {
    if (vpSize_.x < 8 || vpSize_.y < 8) return;
    const bool editing = state_ == PlayState::Stopped;
    const Camera& cam = editing ? editorCam_ : scene_.camera;

    rend_.begin(cam, (int)vpPos_.x, (int)vpPos_.y, (int)vpSize_.x, (int)vpSize_.y, scene_.sky);
    if (editing) rend_.drawGrid();
    rend_.drawScene(scene_);

    if (editing) {
        const View& v = rend_.view();

        // marcadores de luz / objetos vazios
        for (const Entity& e : scene_.entities) {
            if (e.mesh != MeshType::None || !scene_.activeInHierarchy(e)) continue;
            Mat4 W = scene_.worldMatrix(e);
            bool sel = e.id == selected_;
            uint32_t col = e.hasLight ? (sel ? 0xFFFFE040 : 0xDCFFB400) : (sel ? 0xFFFFFFFF : 0xDC50C8FF);
            rend_.marker(W.translation(), col, sel ? 9 : 7);
            if (e.hasLight && e.light.type == LightType::Directional)
                rend_.line(W.translation(), W.translation() + W.dir(Vec3(0, 0, -1)).normalized() * 1.5f, 0xFFFFB400, 2.0f);
        }

        // contorno e gizmo do objeto selecionado
        if (const Entity* e = scene_.find(selected_)) {
            if (e->mesh != MeshType::None) rend_.box(scene_.worldMatrix(*e), meshHalfExtentsFor(e->mesh, e->model), 0xFFFFE040);
            GizmoGeom g;
            if (gizmoGeom(v, g)) {
                for (int i = 0; i < 3; i++) {
                    uint32_t col = gizmoColor(i);
                    if (gizmoMode_ == GizmoMode::Rotate) {
                        static const float radius[3] = {0.55f, 0.95f, 0.75f};
                        rend_.ring(g.origin, g.axes[(i + 1) % 3], g.axes[(i + 2) % 3], g.len * radius[i], col, 3.0f);
                        continue;
                    }
                    Vec3 tip = g.origin + g.axes[i] * g.len;
                    rend_.line(g.origin, tip, col, 3.0f);
                    if (gizmoMode_ == GizmoMode::Scale) {
                        rend_.marker(tip, col, 5);
                    } else {   // ponta de seta
                        Vec3 a = g.axes[(i + 1) % 3], b = g.axes[(i + 2) % 3];
                        Vec3 back = tip - g.axes[i] * (g.len * 0.15f);
                        float w = g.len * 0.06f;
                        rend_.line(tip, back + a * w, col, 3.0f);
                        rend_.line(tip, back - a * w, col, 3.0f);
                        rend_.line(tip, back + b * w, col, 3.0f);
                        rend_.line(tip, back - b * w, col, 3.0f);
                    }
                }
            }
        }
    }
    rend_.end();
}
