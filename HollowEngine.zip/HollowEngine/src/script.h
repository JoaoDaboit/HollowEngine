// script.h - scripts Lua por entidade (única dependência externa nova da engine)
#pragma once
#include <string>
#include <vector>
#include "console.h"
#include "input.h"
#include "scene.h"

struct lua_State;

class ScriptSystem {
public:
    ScriptSystem() = default;
    ~ScriptSystem() { stop(); }
    ScriptSystem(const ScriptSystem&) = delete;
    ScriptSystem& operator=(const ScriptSystem&) = delete;

    // Cria o estado Lua, carrega o script de cada entidade ativa e chama on_start(self)
    bool start(Scene* scene, Input* input, Console* console);
    // Chama on_update(self, dt) em cada script
    void update(float dt);
    void stop();
    bool running() const { return L_ != nullptr; }

    // Usados pelas funções expostas ao Lua (script.cpp)
    Scene* scene = nullptr;
    Input* input = nullptr;
    Console* console = nullptr;
    float dt = 0.0f, elapsed = 0.0f;
    int hookTicks = 0;

private:
    struct Instance {
        int entityId = 0;
        int envRef = 0;    // tabela de ambiente do script (guardada no registry)
        int selfRef = 0;   // objeto 'self' passado aos callbacks
        std::string path;
        bool failed = false;
    };

    bool loadInstance(const Entity& e);
    bool call(Instance& inst, const char* fn, bool withDt);

    lua_State* L_ = nullptr;
    std::vector<Instance> instances_;
};
