#include "animation.h"

const char* const kChannelNames[3] = {"Posição", "Rotação", "Escala"};
const char* const kInterpNames[3] = {"Linear", "Degrau", "Suave"};

bool AnimTrack::sample(float t, Vec3& out) const {
    if (keys.empty()) return false;
    if (t <= keys.front().time) { out = keys.front().value; return true; }
    if (t >= keys.back().time) { out = keys.back().value; return true; }
    for (size_t i = 0; i + 1 < keys.size(); i++) {
        const Keyframe& a = keys[i];
        const Keyframe& b = keys[i + 1];
        if (t >= a.time && t < b.time) {
            float span = b.time - a.time;
            float f = span > 1e-6f ? (t - a.time) / span : 1.0f;
            switch (a.interp) {
                case Interp::Step: out = a.value; break;
                case Interp::Smooth: f = f * f * (3.0f - 2.0f * f); out = lerp(a.value, b.value, f); break;
                default: out = lerp(a.value, b.value, f); break;
            }
            return true;
        }
    }
    out = keys.back().value;
    return true;
}

void AnimTrack::setKey(float t, const Vec3& v, Interp i) {
    t = std::max(0.0f, t);
    for (Keyframe& k : keys)
        if (std::fabs(k.time - t) < 1e-4f) { k.value = v; k.interp = i; return; }
    Keyframe nk;
    nk.time = t; nk.value = v; nk.interp = i;
    auto it = std::upper_bound(keys.begin(), keys.end(), nk,
                               [](const Keyframe& a, const Keyframe& b) { return a.time < b.time; });
    keys.insert(it, nk);
}

void AnimTrack::removeKey(int index) {
    if (index >= 0 && index < (int)keys.size()) keys.erase(keys.begin() + index);
}

AnimTrack* AnimClip::track(AnimChannel c, bool create) {
    for (AnimTrack& t : tracks) if (t.channel == c) return &t;
    if (!create) return nullptr;
    AnimTrack t;
    t.channel = c;
    tracks.push_back(t);
    return &tracks.back();
}

const AnimTrack* AnimClip::track(AnimChannel c) const {
    for (const AnimTrack& t : tracks) if (t.channel == c) return &t;
    return nullptr;
}

void AnimClip::sample(float t, Transform& out) const {
    for (const AnimTrack& tr : tracks) {
        Vec3 v;
        if (!tr.sample(t, v)) continue;
        switch (tr.channel) {
            case AnimChannel::Position: out.pos = v; break;
            case AnimChannel::Rotation: out.rot = v; break;
            case AnimChannel::Scale: out.scale = v; break;
        }
    }
}

void AnimClip::fitDuration() {
    for (const AnimTrack& t : tracks) duration = std::max(duration, t.lastTime());
    duration = std::max(duration, 0.01f);
}

int Animator::find(const std::string& name) const {
    for (size_t i = 0; i < clips.size(); i++) if (clips[i].name == name) return (int)i;
    return -1;
}

bool Animator::play(const std::string& name, bool restart) {
    int idx = find(name);
    if (idx < 0) return false;
    if (restart || current != idx) time = 0;
    current = idx;
    playing = true;
    return true;
}

void Animator::update(float dt, Transform& t) {
    if (!playing || current < 0 || current >= (int)clips.size()) return;
    const AnimClip& c = clips[current];
    time += dt * speed;
    float d = std::max(c.duration, 0.01f);
    if (time >= d) {
        if (c.loop) time = std::fmod(time, d);
        else { time = d; playing = false; }
    }
    c.sample(time, t);
}
