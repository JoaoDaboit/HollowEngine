#include "renderer.h"
#include <cstdio>

static SDL_Color toColor(uint32_t argb) {
    return SDL_Color{(Uint8)((argb >> 16) & 0xFF), (Uint8)((argb >> 8) & 0xFF), (Uint8)(argb & 0xFF),
                     (Uint8)((argb >> 24) & 0xFF)};
}

// ---------------------------------------------------------------- texturas

SDL_Texture* Renderer::texture(const std::string& path) {
    auto it = tex_.find(path);
    if (it != tex_.end()) return it->second;
    SDL_Texture* t = nullptr;
    SDL_Surface* s = IMG_Load(path.c_str());
    if (!s) {
        std::fprintf(stderr, "Textura '%s' não carregou: %s\n", path.c_str(), IMG_GetError());
    } else {
        t = SDL_CreateTextureFromSurface(r_, s);
        SDL_FreeSurface(s);
    }
    tex_[path] = t;   // guarda também a falha, para não tentar carregar todo frame
    return t;
}

void Renderer::clearTextures() {
    for (auto& kv : tex_) if (kv.second) SDL_DestroyTexture(kv.second);
    tex_.clear();
}

// ---------------------------------------------------------------- viewport

void Renderer::begin(const Camera& cam, int x, int y, int w, int h, uint32_t skyArgb) {
    SDL_Rect vp{x, y, w, h};
    SDL_RenderSetViewport(r_, &vp);
    SDL_SetRenderDrawBlendMode(r_, SDL_BLENDMODE_BLEND);
    SDL_Color c = toColor(skyArgb);
    SDL_SetRenderDrawColor(r_, c.r, c.g, c.b, 255);
    SDL_Rect full{0, 0, w, h};
    SDL_RenderFillRect(r_, &full);
    view_ = cam.view(w, h);
}

void Renderer::end() { SDL_RenderSetViewport(r_, nullptr); }

// ---------------------------------------------------------------- linhas e auxiliares

void Renderer::lineScreen(const Vec2& a, const Vec2& b, float thickness, uint32_t argb) {
    SDL_Color c = toColor(argb);
    if (thickness <= 1.5f) {
        SDL_SetRenderDrawColor(r_, c.r, c.g, c.b, c.a);
        SDL_RenderDrawLineF(r_, a.x, a.y, b.x, b.y);
        return;
    }
    Vec2 d = b - a;
    float len = d.length();
    if (len < 0.001f) return;
    Vec2 n(-d.y / len * thickness * 0.5f, d.x / len * thickness * 0.5f);
    SDL_Vertex v[4];
    const Vec2 pts[4] = {a + n, a - n, b - n, b + n};
    for (int i = 0; i < 4; i++) {
        v[i].position = {pts[i].x, pts[i].y};
        v[i].color = c;
        v[i].tex_coord = {0, 0};
    }
    const int idx[6] = {0, 1, 2, 0, 2, 3};
    SDL_RenderGeometry(r_, nullptr, v, 4, idx, 6);
}

void Renderer::line(const Vec3& a, const Vec3& b, uint32_t argb, float thickness) {
    const float nz = view_.nearZ + 1e-3f;
    float da = view_.depth(a), db = view_.depth(b);
    if (da < nz && db < nz) return;
    Vec3 pa = a, pb = b;
    if (da < nz) pa = a + (b - a) * ((nz - da) / (db - da));
    else if (db < nz) pb = b + (a - b) * ((nz - db) / (da - db));
    Vec2 sa, sb;
    if (!view_.project(pa, sa) || !view_.project(pb, sb)) return;
    lineScreen(sa, sb, thickness, argb);
}

void Renderer::drawGrid(int extent) {
    for (int i = -extent; i <= extent; i++) {
        uint32_t cx = i == 0 ? 0xC8D05050 : 0x78646496;   // eixo Z em vermelho, resto cinza-azulado
        uint32_t cz = i == 0 ? 0xC85050D0 : 0x78646496;   // eixo X em azul
        line(Vec3((float)i, 0, (float)-extent), Vec3((float)i, 0, (float)extent), cx);
        line(Vec3((float)-extent, 0, (float)i), Vec3((float)extent, 0, (float)i), cz);
    }
}

void Renderer::box(const Mat4& world, const Vec3& half, uint32_t argb) {
    Vec3 c[8];
    for (int i = 0; i < 8; i++)
        c[i] = world.point(Vec3((i & 1) ? half.x : -half.x, (i & 2) ? half.y : -half.y, (i & 4) ? half.z : -half.z));
    for (int i = 0; i < 8; i++)
        for (int bit = 1; bit <= 4; bit <<= 1)
            if (!(i & bit)) line(c[i], c[i | bit], argb, 1.0f);
}

void Renderer::ring(const Vec3& center, const Vec3& u, const Vec3& v, float radius, uint32_t argb,
                    float thickness, int segments) {
    Vec3 prev = center + u * radius;
    for (int i = 1; i <= segments; i++) {
        float a = (float)i / segments * 2.0f * kPi;
        Vec3 p = center + u * (std::cos(a) * radius) + v * (std::sin(a) * radius);
        line(prev, p, argb, thickness);
        prev = p;
    }
}

void Renderer::marker(const Vec3& p, uint32_t argb, int halfSize) {
    Vec2 s;
    if (!view_.project(p, s)) return;
    SDL_Color c = toColor(argb);
    SDL_Rect r{(int)(s.x - halfSize), (int)(s.y - halfSize), halfSize * 2, halfSize * 2};
    SDL_SetRenderDrawColor(r_, c.r, c.g, c.b, c.a);
    SDL_RenderFillRect(r_, &r);
    SDL_SetRenderDrawColor(r_, 255, 255, 255, 255);
    SDL_RenderDrawRect(r_, &r);
}

// ---------------------------------------------------------------- cena

// Corta o triângulo no plano near (Sutherland-Hodgman) e empilha 1 ou 2 triângulos projetados
void Renderer::pushClipped(const CV in[3], const SDL_Color& col, SDL_Texture* tex, float depth) {
    const float nz = view_.nearZ + 1e-3f;
    CV poly[4];
    int n = 0;
    for (int i = 0; i < 3; i++) {
        const CV& a = in[i];
        const CV& b = in[(i + 1) % 3];
        float da = view_.depth(a.p) - nz, db = view_.depth(b.p) - nz;
        if (da >= 0) poly[n++] = a;
        if ((da >= 0) != (db >= 0)) {
            float t = da / (da - db);
            poly[n++] = CV{a.p + (b.p - a.p) * t, a.uv + (b.uv - a.uv) * t};
        }
    }
    if (n < 3) return;

    Vec2 s[4];
    for (int i = 0; i < n; i++)
        if (!view_.project(poly[i].p, s[i])) return;

    for (int i = 1; i + 1 < n; i++) {
        const int id[3] = {0, i, i + 1};
        float minX = 1e30f, maxX = -1e30f, minY = 1e30f, maxY = -1e30f;
        for (int k : id) {
            minX = std::min(minX, s[k].x); maxX = std::max(maxX, s[k].x);
            minY = std::min(minY, s[k].y); maxY = std::max(maxY, s[k].y);
        }
        if (maxX < 0 || minX > view_.w || maxY < 0 || minY > view_.h) continue;   // fora do viewport
        Tri t;
        t.tex = tex;
        t.depth = depth;
        for (int k = 0; k < 3; k++) {
            t.v[k].position = {s[id[k]].x, s[id[k]].y};
            t.v[k].color = col;
            t.v[k].tex_coord = {poly[id[k]].uv.x, poly[id[k]].uv.y};
        }
        tris_.push_back(t);
    }
}

void Renderer::drawScene(const Scene& scene) {
    struct L { bool dir; Vec3 v; Vec3 col; float inten; };
    std::vector<L> lights;
    for (const Entity& e : scene.entities) {
        if (!e.hasLight || !scene.activeInHierarchy(e)) continue;
        Mat4 w = scene.worldMatrix(e);
        bool dir = e.light.type == LightType::Directional;
        lights.push_back({dir, dir ? w.dir(Vec3(0, 0, -1)).normalized() : w.translation(), e.light.color,
                          e.light.intensity});
    }
    // Sem nenhuma luz na cena, usa uma direcional padrão para o editor continuar legível
    if (lights.empty()) lights.push_back({true, Vec3(-0.4f, -1.0f, -0.3f).normalized(), Vec3(1, 1, 1), 0.8f});

    tris_.clear();
    std::vector<Vec3> wp;
    for (const Entity& e : scene.entities) {
        if (e.mesh == MeshType::None || !scene.activeInHierarchy(e)) continue;
        const Mesh& m = meshFor(e.mesh, e.model);
        if (m.pos.empty()) continue;
        Mat4 W = scene.worldMatrix(e);
        wp.resize(m.pos.size());
        for (size_t i = 0; i < m.pos.size(); i++) wp[i] = W.point(m.pos[i]);

        SDL_Texture* tex = e.texture.empty() ? nullptr : texture(e.texture);
        uint32_t base = tex ? 0xFFFFFFFFu : e.color;
        Vec3 baseRGB(((base >> 16) & 0xFF) / 255.0f, ((base >> 8) & 0xFF) / 255.0f, (base & 0xFF) / 255.0f);

        for (size_t t = 0; t < m.triCount(); t++) {
            const Vec3 &a = wp[t * 3], &b = wp[t * 3 + 1], &c = wp[t * 3 + 2];
            Vec3 n = (b - a).cross(c - a);
            float len = n.length();
            if (len < 1e-7f) continue;
            n = n * (1.0f / len);
            Vec3 centro = (a + b + c) * (1.0f / 3.0f);
            if (n.dot(view_.pos - centro) <= 0) continue;   // de costas para a câmera

            float depth = view_.depth(centro);
            if (depth < -1.0f) continue;   // totalmente atrás (margem p/ triângulos grandes cruzando o near)

            Vec3 sum(scene.ambient, scene.ambient, scene.ambient);
            for (const L& l : lights) {
                float k;
                if (l.dir) {
                    k = std::max(0.0f, n.dot(l.v * -1.0f));
                } else {
                    Vec3 to = l.v - centro;
                    float d = std::max(to.length(), 1e-4f);
                    k = std::max(0.0f, n.dot(to * (1.0f / d))) / (1.0f + 0.1f * d + 0.05f * d * d);
                }
                sum += Vec3(l.col.x, l.col.y, l.col.z) * (k * l.inten);
            }
            SDL_Color col{(Uint8)(255.0f * std::min(1.0f, baseRGB.x * sum.x)),
                          (Uint8)(255.0f * std::min(1.0f, baseRGB.y * sum.y)),
                          (Uint8)(255.0f * std::min(1.0f, baseRGB.z * sum.z)), 255};

            CV in[3] = {{a, m.uv[t * 3]}, {b, m.uv[t * 3 + 1]}, {c, m.uv[t * 3 + 2]}};
            pushClipped(in, col, tex, depth);
        }
    }

    std::sort(tris_.begin(), tris_.end(), [](const Tri& a, const Tri& b) { return a.depth > b.depth; });

    SDL_Texture* cur = nullptr;
    batch_.clear();
    auto flush = [&]() {
        if (!batch_.empty()) SDL_RenderGeometry(r_, cur, batch_.data(), (int)batch_.size(), nullptr, 0);
        batch_.clear();
    };
    for (const Tri& t : tris_) {
        if (t.tex != cur) { flush(); cur = t.tex; }
        batch_.insert(batch_.end(), t.v, t.v + 3);
    }
    flush();
}
