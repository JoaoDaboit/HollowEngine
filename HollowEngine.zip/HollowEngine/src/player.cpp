// player.cpp - runtime do jogo exportado: sem editor e sem ImGui.
// Lê data/game.hscene (ou o arquivo passado como argumento), roda scripts Lua e animações e desenha.
// Desktop: a pasta de trabalho vira <pasta do executável>/data. Android: os assets do APK são a raiz.
#include <algorithm>
#include <cstdio>
#include "console.h"
#include "input.h"
#include "renderer.h"
#include "scene.h"
#include "script.h"
#include "vfs.h"
#ifndef __ANDROID__
#include <filesystem>
#endif

static bool readViaSDL(const std::string& path, std::string& out) {
    SDL_RWops* rw = SDL_RWFromFile(path.c_str(), "rb");
    if (!rw) return false;
    Sint64 size = SDL_RWsize(rw);
    if (size < 0) { SDL_RWclose(rw); return false; }
    out.resize((size_t)size);
    size_t got = size ? SDL_RWread(rw, &out[0], 1, (size_t)size) : 0;
    SDL_RWclose(rw);
    out.resize(got);
    return true;
}

int main(int argc, char** argv) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) { std::fprintf(stderr, "SDL_Init: %s\n", SDL_GetError()); return 1; }
    IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG);
    fileReader() = readViaSDL;   // scripts, cena, modelos e texturas passam por aqui

#ifndef __ANDROID__
    if (char* base = SDL_GetBasePath()) {
        std::error_code ec;
        std::filesystem::current_path(std::filesystem::path(base) / "data", ec);
        SDL_free(base);
    }
#endif

    SDL_Window* window = SDL_CreateWindow("HollowEngine Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 720,
                                          SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI | SDL_WINDOW_SHOWN);
    if (!window) { std::fprintf(stderr, "SDL_CreateWindow: %s\n", SDL_GetError()); return 1; }
    SDL_Renderer* sdlRenderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!sdlRenderer) sdlRenderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (!sdlRenderer) { std::fprintf(stderr, "SDL_CreateRenderer: %s\n", SDL_GetError()); return 1; }
    SDL_SetRenderDrawBlendMode(sdlRenderer, SDL_BLENDMODE_BLEND);

    int exitCode = 0;
    {
        Console console;
        Input input;
        Scene scene;
        ScriptSystem scripts;
        Renderer renderer(sdlRenderer);

        const char* sceneFile = argc > 1 ? argv[1] : "game.hscene";
        if (!scene.load(sceneFile)) {
            std::string msg = std::string("Não foi possível abrir a cena: ") + sceneFile;
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "HollowEngine", msg.c_str(), window);
            exitCode = 1;
        } else {
            for (Entity& e : scene.entities)
                if (!e.anim.autoplay.empty()) e.anim.play(e.anim.autoplay);
            input.enabled = true;
            scripts.start(&scene, &input, &console);

            size_t printed = 0;
            bool running = true;
            uint64_t last = SDL_GetPerformanceCounter();
            while (running) {
                SDL_Event ev;
                while (SDL_PollEvent(&ev)) {
                    if (ev.type == SDL_QUIT) running = false;
                    if (ev.type == SDL_KEYDOWN) {
                        if (ev.key.keysym.sym == SDLK_ESCAPE) {
                            if (SDL_GetRelativeMouseMode()) SDL_SetRelativeMouseMode(SDL_FALSE);
                            else running = false;
                        }
                        if (ev.key.keysym.sym == SDLK_F11) {
                            bool fs = (SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN_DESKTOP) != 0;
                            SDL_SetWindowFullscreen(window, fs ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP);
                        }
                    }
                }
                uint64_t now = SDL_GetPerformanceCounter();
                float dt = std::min(0.1f, (float)((double)(now - last) / (double)SDL_GetPerformanceFrequency()));
                last = now;

                int w = 0, h = 0;
                SDL_GetWindowSize(window, &w, &h);
                input.update();
                SDL_GetMouseState(&input.mx, &input.my);
                input.screenW = w;
                input.screenH = h;

                scripts.update(dt);
                for (Entity& e : scene.entities)
                    if (scene.activeInHierarchy(e)) e.anim.update(dt, e.t);
                scene.flushDestroy();

                SDL_SetRenderDrawColor(sdlRenderer, 0, 0, 0, 255);
                SDL_RenderClear(sdlRenderer);
                renderer.begin(scene.camera, 0, 0, w, h, scene.sky);
                renderer.drawScene(scene);
                renderer.end();
                SDL_RenderPresent(sdlRenderer);

                for (; printed < console.lines.size(); printed++)   // log() dos scripts -> terminal / logcat
                    SDL_Log("%s", console.lines[printed].second.c_str());
                if (console.lines.size() < printed) printed = console.lines.size();
            }
            scripts.stop();
        }
    }

    SDL_DestroyRenderer(sdlRenderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
    return exitCode;
}
