// input.h - estado do teclado/mouse visto pelos scripts
#pragma once
#include "sdl_compat.h"
#include <algorithm>
#include <cstring>

struct Input {
    uint8_t cur[SDL_NUM_SCANCODES] = {};
    uint8_t prev[SDL_NUM_SCANCODES] = {};
    uint32_t mouseCur = 0, mousePrev = 0;
    int dx = 0, dy = 0;
    int mx = 0, my = 0;               // posição do ponteiro na área do jogo (preenchida por quem chama)
    int screenW = 0, screenH = 0;     // tamanho da área do jogo
    bool enabled = false;   // scripts só recebem input quando o viewport está ativo (e não há texto sendo digitado)

    void update() {   // chamar uma vez por frame
        std::memcpy(prev, cur, sizeof cur);
        int n = 0;
        const uint8_t* k = SDL_GetKeyboardState(&n);
        std::memset(cur, 0, sizeof cur);
        std::memcpy(cur, k, std::min<size_t>((size_t)n, sizeof cur));
        mousePrev = mouseCur;
        mouseCur = SDL_GetRelativeMouseState(&dx, &dy);
    }

    bool down(SDL_Scancode s) const { return enabled && cur[s]; }
    bool pressed(SDL_Scancode s) const { return enabled && cur[s] && !prev[s]; }
    bool released(SDL_Scancode s) const { return enabled && !cur[s] && prev[s]; }
    bool mouseDown(int button) const { return enabled && (mouseCur & SDL_BUTTON(button)); }
};
