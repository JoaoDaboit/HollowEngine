#include "mesh.h"
#include "vfs.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <locale>
#include <sstream>
#include <unordered_map>

const char* const kMeshNames[kMeshTypeCount] = {"Cubo", "Plano", "Cone", "Esfera", "Vazio", "Modelo"};

namespace {

void tri(Mesh& m, Vec3 a, Vec2 ta, Vec3 b, Vec2 tb, Vec3 c, Vec2 tc) {
    m.pos.push_back(a); m.uv.push_back(ta);
    m.pos.push_back(b); m.uv.push_back(tb);
    m.pos.push_back(c); m.uv.push_back(tc);
}

// Quad 1x1 subdividido em n x n células. Normal = u x v. Subdividir melhora a iluminação por
// triângulo e reduz a distorção da textura (o rasterizador não faz correção de perspectiva).
void quadGrid(Mesh& m, Vec3 center, Vec3 u, Vec3 v, int n) {
    for (int ix = 0; ix < n; ix++)
        for (int iy = 0; iy < n; iy++) {
            float u0 = -0.5f + (float)ix / n, u1 = -0.5f + (float)(ix + 1) / n;
            float v0 = -0.5f + (float)iy / n, v1 = -0.5f + (float)(iy + 1) / n;
            Vec3 a = center + u * u0 + v * v0, b = center + u * u1 + v * v0;
            Vec3 c = center + u * u1 + v * v1, d = center + u * u0 + v * v1;
            Vec2 ta(u0 + 0.5f, 1 - (v0 + 0.5f)), tb(u1 + 0.5f, 1 - (v0 + 0.5f));
            Vec2 tc(u1 + 0.5f, 1 - (v1 + 0.5f)), td(u0 + 0.5f, 1 - (v1 + 0.5f));
            tri(m, a, ta, b, tb, c, tc);
            tri(m, a, ta, c, tc, d, td);
        }
}

Mesh buildCube() {
    Mesh m;
    struct F { Vec3 n, u, v; };
    const F faces[6] = {
        {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}},  {{-1, 0, 0}, {0, 0, 1}, {0, 1, 0}},
        {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}},  {{0, -1, 0}, {1, 0, 0}, {0, 0, 1}},
        {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}},  {{0, 0, -1}, {0, 1, 0}, {1, 0, 0}},
    };
    for (const F& f : faces) quadGrid(m, f.n * 0.5f, f.u, f.v, 4);
    return m;
}

Mesh buildPlane() {   // duas faces para nunca ficar invisível
    Mesh m;
    quadGrid(m, Vec3(), Vec3(0, 0, 1), Vec3(1, 0, 0), 8);   // +Y
    quadGrid(m, Vec3(), Vec3(1, 0, 0), Vec3(0, 0, 1), 8);   // -Y
    return m;
}

Mesh buildSphere() {
    Mesh m;
    const int rings = 12, seg = 16;
    const float r = 0.5f;
    auto P = [&](int i, int j) {
        float phi = (float)i / rings * kPi, th = (float)j / seg * 2.0f * kPi;
        float s = (i == 0 || i == rings) ? 0.0f : std::sin(phi);   // polos exatos (sem triângulos quase degenerados)
        return Vec3(std::cos(th) * s * r, std::cos(phi) * r, std::sin(th) * s * r);
    };
    auto T = [&](int i, int j) { return Vec2((float)j / seg, (float)i / rings); };
    for (int i = 0; i < rings; i++)
        for (int j = 0; j < seg; j++) {
            tri(m, P(i, j), T(i, j), P(i, j + 1), T(i, j + 1), P(i + 1, j), T(i + 1, j));
            tri(m, P(i, j + 1), T(i, j + 1), P(i + 1, j + 1), T(i + 1, j + 1), P(i + 1, j), T(i + 1, j));
        }
    return m;
}

Mesh buildCone() {
    Mesh m;
    const int seg = 20;
    const float r = 0.5f;
    Vec3 apex(0, 0.5f, 0), base(0, -0.5f, 0);
    for (int i = 0; i < seg; i++) {
        float a0 = (float)i / seg * 2.0f * kPi, a1 = (float)(i + 1) / seg * 2.0f * kPi;
        Vec3 b0(std::cos(a0) * r, -0.5f, std::sin(a0) * r), b1(std::cos(a1) * r, -0.5f, std::sin(a1) * r);
        float u0 = (float)i / seg, u1 = (float)(i + 1) / seg;
        tri(m, apex, Vec2((u0 + u1) * 0.5f, 0), b1, Vec2(u1, 1), b0, Vec2(u0, 1));   // lado
        tri(m, base, Vec2(0.5f, 0.5f), b0, Vec2(0.5f + b0.x, 0.5f + b0.z),
            b1, Vec2(0.5f + b1.x, 0.5f + b1.z));                                       // base
    }
    return m;
}

}  // namespace

const Mesh& getMesh(MeshType t) {
    static const Mesh cube = buildCube(), plane = buildPlane(), cone = buildCone(), sphere = buildSphere();
    static const Mesh none;
    switch (t) {
        case MeshType::Cube: return cube;
        case MeshType::Plane: return plane;
        case MeshType::Cone: return cone;
        case MeshType::Sphere: return sphere;
        default: return none;
    }
}

Vec3 meshHalfExtents(MeshType t) {
    switch (t) {
        case MeshType::Plane: return {0.5f, 0.02f, 0.5f};
        case MeshType::None: return {0.15f, 0.15f, 0.15f};
        default: return {0.5f, 0.5f, 0.5f};
    }
}

// ---------------------------------------------------------------- importação OBJ

bool loadObj(const std::string& path, Mesh& out, std::string* error) {
    std::string data;
    if (!readFile(path, data)) { if (error) *error = "arquivo não encontrado"; return false; }
    std::istringstream f(data);
    f.imbue(std::locale::classic());

    std::vector<Vec3> v;
    std::vector<Vec2> vt;
    Mesh m;
    std::string line;
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        ss.imbue(std::locale::classic());
        std::string kw;
        if (!(ss >> kw)) continue;
        if (kw == "v") {
            float x = 0, y = 0, z = 0;
            ss >> x >> y >> z;
            v.push_back(Vec3(x, y, z));
        } else if (kw == "vt") {
            float u = 0, w = 0;
            ss >> u >> w;
            vt.push_back(Vec2(u, 1.0f - w));   // OBJ tem a origem da textura embaixo
        } else if (kw == "f") {
            std::vector<std::pair<int, int>> corners;   // (vértice, uv); -1 = ausente
            std::string tok;
            bool bad = false;
            while (ss >> tok) {
                size_t s1 = tok.find('/');
                int vi = std::atoi(tok.substr(0, s1).c_str()), ti = 0;
                if (s1 != std::string::npos) {
                    size_t s2 = tok.find('/', s1 + 1);
                    std::string t = tok.substr(s1 + 1, s2 == std::string::npos ? std::string::npos : s2 - s1 - 1);
                    if (!t.empty()) ti = std::atoi(t.c_str());
                }
                vi = vi < 0 ? (int)v.size() + vi : vi - 1;       // índices negativos contam do fim
                ti = ti < 0 ? (int)vt.size() + ti : (ti == 0 ? -1 : ti - 1);
                if (vi < 0 || vi >= (int)v.size()) { bad = true; break; }
                if (ti >= (int)vt.size()) ti = -1;
                corners.push_back({vi, ti});
            }
            if (bad || corners.size() < 3) continue;
            for (size_t i = 1; i + 1 < corners.size(); i++) {   // polígono -> leque de triângulos
                const std::pair<int, int>* c[3] = {&corners[0], &corners[i], &corners[i + 1]};
                for (auto* k : c) {
                    m.pos.push_back(v[k->first]);
                    m.uv.push_back(k->second >= 0 ? vt[k->second] : Vec2(0, 0));
                }
            }
        }
    }
    if (m.pos.empty()) { if (error) *error = "o arquivo não tem faces"; return false; }

    // Centraliza e escala para caber em 1 unidade
    Vec3 lo(1e30f, 1e30f, 1e30f), hi(-1e30f, -1e30f, -1e30f);
    for (const Vec3& p : m.pos)
        for (int k = 0; k < 3; k++) { lo[k] = std::min(lo[k], p[k]); hi[k] = std::max(hi[k], p[k]); }
    Vec3 center = (lo + hi) * 0.5f, ext = hi - lo;
    float biggest = std::max(ext.x, std::max(ext.y, ext.z));
    float s = biggest > 1e-9f ? 1.0f / biggest : 1.0f;
    for (Vec3& p : m.pos) p = (p - center) * s;
    m.half = Vec3(std::max(ext.x * s * 0.5f, 0.01f), std::max(ext.y * s * 0.5f, 0.01f), std::max(ext.z * s * 0.5f, 0.01f));
    out = m;
    return true;
}

static std::unordered_map<std::string, Mesh>& modelCache() {
    static std::unordered_map<std::string, Mesh> cache;
    return cache;
}

void clearModelCache() { modelCache().clear(); }

const Mesh& meshFor(MeshType t, const std::string& modelPath) {
    if (t != MeshType::Model) return getMesh(t);
    static const Mesh empty;
    if (modelPath.empty()) return empty;
    auto& cache = modelCache();
    auto it = cache.find(modelPath);
    if (it != cache.end()) return it->second;
    Mesh m;
    std::string err;
    if (!loadObj(modelPath, m, &err)) {
        std::fprintf(stderr, "Modelo '%s' não carregou: %s\n", modelPath.c_str(), err.c_str());
        m = Mesh();   // guarda a falha para não tentar todo frame
    }
    return cache.emplace(modelPath, std::move(m)).first->second;
}

Vec3 meshHalfExtentsFor(MeshType t, const std::string& modelPath) {
    if (t != MeshType::Model) return meshHalfExtents(t);
    const Mesh& m = meshFor(t, modelPath);
    return m.pos.empty() ? Vec3(0.15f, 0.15f, 0.15f) : m.half;
}
