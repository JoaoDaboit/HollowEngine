// HollowEngine - ponto de entrada: janela, laço principal e ligação dos módulos
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>
#include "imgui/backends/imgui_impl_sdl2.h"
#include "imgui/backends/imgui_impl_sdlrenderer2.h"
#include "imgui/imgui.h"

#include "console.h"
#include "editor.h"
#include "input.h"
#include "renderer.h"
#include "scene.h"
#include "script.h"

// Fundo roxo em degradê radial (mesmo visual do Engine.cpp original)
static SDL_Texture* makeBackground(SDL_Renderer* r, int w, int h) {
    SDL_Texture* tex = SDL_CreateTexture(r, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, w, h);
    if (!tex) return nullptr;
    std::vector<uint32_t> px((size_t)w * h);
    const float cx = w / 2.0f, cy = h / 2.0f, maxd = std::sqrt(cx * cx + cy * cy);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            float d = std::min(1.0f, std::sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxd);
            uint8_t rr = (uint8_t)((1 - d) * 180 + d * 30), gg = (uint8_t)((1 - d) * 40), bb = (uint8_t)((1 - d) * 220 + d * 100);
            px[(size_t)y * w + x] = (255u << 24) | (rr << 16) | (gg << 8) | bb;
        }
    SDL_UpdateTexture(tex, nullptr, px.data(), w * (int)sizeof(uint32_t));
    return tex;
}

int main(int, char**) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) { std::fprintf(stderr, "SDL_Init: %s\n", SDL_GetError()); return 1; }
    if (!(IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG) & IMG_INIT_PNG)) std::fprintf(stderr, "SDL_image: %s\n", IMG_GetError());

    SDL_Window* window = SDL_CreateWindow("HollowEngine", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 800,
                                          SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if (!window) { std::fprintf(stderr, "SDL_CreateWindow: %s\n", SDL_GetError()); SDL_Quit(); return 1; }

    SDL_Renderer* sdlRenderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!sdlRenderer) sdlRenderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (!sdlRenderer) { std::fprintf(stderr, "SDL_CreateRenderer: %s\n", SDL_GetError()); SDL_DestroyWindow(window); SDL_Quit(); return 1; }
    SDL_SetRenderDrawBlendMode(sdlRenderer, SDL_BLENDMODE_BLEND);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();
    ImGui_ImplSDL2_InitForSDLRenderer(window, sdlRenderer);
    ImGui_ImplSDLRenderer2_Init(sdlRenderer);

    SDL_Texture* background = makeBackground(sdlRenderer, 1080, 720);

    {   // escopo: tudo aqui dentro é destruído antes do SDL_Renderer
        Console console;
        Input input;
        Scene scene;
        ScriptSystem scripts;
        Renderer renderer(sdlRenderer);
        Editor editor(renderer, scene, scripts, input, console);
        editor.openStartScene();

        bool running = true;
        uint64_t last = SDL_GetPerformanceCounter();
        while (running) {
            SDL_Event ev;
            while (SDL_PollEvent(&ev)) {
                ImGui_ImplSDL2_ProcessEvent(&ev);
                if (ev.type == SDL_QUIT) running = false;
                if (ev.type == SDL_KEYDOWN) {
                    if (ev.key.keysym.sym == SDLK_ESCAPE && SDL_GetRelativeMouseMode()) SDL_SetRelativeMouseMode(SDL_FALSE);
                    if (ev.key.keysym.sym == SDLK_F11) {
                        bool fs = (SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN_DESKTOP) != 0;
                        SDL_SetWindowFullscreen(window, fs ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP);
                    }
                }
            }

            uint64_t now = SDL_GetPerformanceCounter();
            float dt = (float)((double)(now - last) / (double)SDL_GetPerformanceFrequency());
            last = now;
            dt = std::min(dt, 0.1f);   // evita saltos enormes depois de uma pausa

            input.update();

            SDL_SetRenderDrawColor(sdlRenderer, 0, 0, 0, 255);
            SDL_RenderClear(sdlRenderer);
            if (background) SDL_RenderCopy(sdlRenderer, background, nullptr, nullptr);

            ImGui_ImplSDLRenderer2_NewFrame();
            ImGui_ImplSDL2_NewFrame();
            ImGui::NewFrame();

            editor.ui();          // painéis (também calcula o retângulo do viewport)
            editor.interact(dt);  // câmera, seleção, gizmos
            editor.update(dt);    // scripts Lua + animações (modo Play)
            editor.render();      // 3D dentro do viewport, por baixo dos painéis

            ImGui::Render();
            ImGui_ImplSDLRenderer2_RenderDrawData(ImGui::GetDrawData(), sdlRenderer);
            SDL_RenderPresent(sdlRenderer);
        }
        scripts.stop();
    }

    ImGui_ImplSDLRenderer2_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    if (background) SDL_DestroyTexture(background);
    SDL_DestroyRenderer(sdlRenderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
    return 0;
}
