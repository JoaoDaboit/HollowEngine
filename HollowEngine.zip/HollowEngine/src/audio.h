// audio.h - áudio da engine: mixer por software sobre o SDL2 (sem biblioteca nova).
// Formato suportado: WAV PCM/float (8/16/24/32 bits, mono ou estéreo). É convertido na carga para 44100 Hz, estéreo, 16 bits.
// Os arquivos são lidos por readFile() (vfs.h), então funciona no editor, no player e dentro do APK.
#pragma once
#include <string>

namespace Audio {

// Abre o dispositivo de áudio na primeira chamada. Retorna false se não houver áudio (a engine continua sem som).
bool init(std::string* error = nullptr);
void shutdown();                 // fecha o dispositivo e libera os sons
void stopAll();                  // para todas as vozes (mantém os sons carregados em cache)

// Toca um som. Retorna o id da voz (> 0) ou 0 em caso de erro.
// volume: 0..1+ | pan: -1 (esquerda) .. 1 (direita) | loop: repete até stop()
int play(const std::string& path, float volume, bool loop, float pan, std::string* error = nullptr);

void stop(int voice);
bool isPlaying(int voice);
void setVolume(int voice, float volume);
void setPan(int voice, float pan);
void setMasterVolume(float volume);   // 0..1
float masterVolume();
bool available();

}  // namespace Audio
