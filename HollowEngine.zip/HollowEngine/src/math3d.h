// math3d.h - matemática básica da engine (sem dependências)
#pragma once
#include <algorithm>
#include <cmath>

constexpr float kPi = 3.14159265358979f;
inline float radians(float d) { return d * kPi / 180.0f; }

struct Vec2 {
    float x = 0, y = 0;
    Vec2() = default;
    Vec2(float x, float y) : x(x), y(y) {}
    Vec2 operator+(const Vec2& v) const { return {x + v.x, y + v.y}; }
    Vec2 operator-(const Vec2& v) const { return {x - v.x, y - v.y}; }
    Vec2 operator*(float s) const { return {x * s, y * s}; }
    float dot(const Vec2& v) const { return x * v.x + y * v.y; }
    float length() const { return std::sqrt(x * x + y * y); }
};

struct Vec3 {
    float x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(float x, float y, float z) : x(x), y(y), z(z) {}
    Vec3 operator+(const Vec3& v) const { return {x + v.x, y + v.y, z + v.z}; }
    Vec3 operator-(const Vec3& v) const { return {x - v.x, y - v.y, z - v.z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
    Vec3& operator+=(const Vec3& v) { x += v.x; y += v.y; z += v.z; return *this; }
    float dot(const Vec3& v) const { return x * v.x + y * v.y + z * v.z; }
    Vec3 cross(const Vec3& v) const { return {y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x}; }
    float length() const { return std::sqrt(x * x + y * y + z * z); }
    Vec3 normalized() const {
        float l = length();
        return l > 1e-8f ? Vec3(x / l, y / l, z / l) : Vec3();
    }
    float& operator[](int i) { return i == 0 ? x : (i == 1 ? y : z); }
    float operator[](int i) const { return i == 0 ? x : (i == 1 ? y : z); }
};

inline Vec3 lerp(const Vec3& a, const Vec3& b, float t) { return a + (b - a) * t; }

// Matriz afim 4x4 (linha-major, vetores coluna: p' = M * p)
struct Mat4 {
    float m[4][4];

    static Mat4 identity() {
        Mat4 r{};
        for (int i = 0; i < 4; i++) r.m[i][i] = 1.0f;
        return r;
    }

    Mat4 operator*(const Mat4& o) const {
        Mat4 r{};
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += m[i][k] * o.m[k][j];
                r.m[i][j] = s;
            }
        return r;
    }

    Vec3 point(const Vec3& p) const {
        return {m[0][0] * p.x + m[0][1] * p.y + m[0][2] * p.z + m[0][3],
                m[1][0] * p.x + m[1][1] * p.y + m[1][2] * p.z + m[1][3],
                m[2][0] * p.x + m[2][1] * p.y + m[2][2] * p.z + m[2][3]};
    }
    Vec3 dir(const Vec3& p) const {
        return {m[0][0] * p.x + m[0][1] * p.y + m[0][2] * p.z,
                m[1][0] * p.x + m[1][1] * p.y + m[1][2] * p.z,
                m[2][0] * p.x + m[2][1] * p.y + m[2][2] * p.z};
    }
    Vec3 translation() const { return {m[0][3], m[1][3], m[2][3]}; }
    Vec3 axis(int i) const { return {m[0][i], m[1][i], m[2][i]}; }

    // T * R * S, com rotação em graus aplicada na ordem X, Y, Z (R = Rz*Ry*Rx)
    static Mat4 trs(const Vec3& pos, const Vec3& rotDeg, const Vec3& scale) {
        float cx = std::cos(radians(rotDeg.x)), sx = std::sin(radians(rotDeg.x));
        float cy = std::cos(radians(rotDeg.y)), sy = std::sin(radians(rotDeg.y));
        float cz = std::cos(radians(rotDeg.z)), sz = std::sin(radians(rotDeg.z));
        Mat4 rx = identity(), ry = identity(), rz = identity();
        rx.m[1][1] = cx; rx.m[1][2] = -sx; rx.m[2][1] = sx; rx.m[2][2] = cx;
        ry.m[0][0] = cy; ry.m[0][2] = sy;  ry.m[2][0] = -sy; ry.m[2][2] = cy;
        rz.m[0][0] = cz; rz.m[0][1] = -sz; rz.m[1][0] = sz; rz.m[1][1] = cz;
        Mat4 r = rz * ry * rx;
        for (int i = 0; i < 3; i++) {
            r.m[i][0] *= scale.x;
            r.m[i][1] *= scale.y;
            r.m[i][2] *= scale.z;
        }
        r.m[0][3] = pos.x; r.m[1][3] = pos.y; r.m[2][3] = pos.z;
        return r;
    }

    // Inversa de uma matriz afim (última linha 0 0 0 1)
    Mat4 inverseAffine() const {
        float a = m[0][0], b = m[0][1], c = m[0][2];
        float d = m[1][0], e = m[1][1], f = m[1][2];
        float g = m[2][0], h = m[2][1], i = m[2][2];
        float A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
        float det = a * A + b * B + c * C;
        if (std::fabs(det) < 1e-12f) return identity();
        float id = 1.0f / det;
        Mat4 r = identity();
        r.m[0][0] = A * id; r.m[0][1] = -(b * i - c * h) * id; r.m[0][2] = (b * f - c * e) * id;
        r.m[1][0] = B * id; r.m[1][1] = (a * i - c * g) * id;  r.m[1][2] = -(a * f - c * d) * id;
        r.m[2][0] = C * id; r.m[2][1] = -(a * h - b * g) * id; r.m[2][2] = (a * e - b * d) * id;
        Vec3 t = translation();
        for (int k = 0; k < 3; k++)
            r.m[k][3] = -(r.m[k][0] * t.x + r.m[k][1] * t.y + r.m[k][2] * t.z);
        return r;
    }
};

struct Transform {
    Vec3 pos{0, 0, 0};
    Vec3 rot{0, 0, 0};   // graus
    Vec3 scale{1, 1, 1};
    Mat4 matrix() const { return Mat4::trs(pos, rot, scale); }
};

// Interseção raio x caixa centrada na origem (espaço local)
inline bool rayBox(const Vec3& o, const Vec3& d, const Vec3& half, float& tHit) {
    float tmin = -1e30f, tmax = 1e30f;
    for (int i = 0; i < 3; i++) {
        float oi = o[i], di = d[i], hi = half[i];
        if (std::fabs(di) < 1e-8f) {
            if (oi < -hi || oi > hi) return false;
        } else {
            float t1 = (-hi - oi) / di, t2 = (hi - oi) / di;
            if (t1 > t2) std::swap(t1, t2);
            tmin = std::max(tmin, t1);
            tmax = std::min(tmax, t2);
            if (tmin > tmax) return false;
        }
    }
    if (tmax < 0) return false;
    tHit = tmin > 0 ? tmin : tmax;
    return true;
}
