#include "script.h"
#include "vfs.h"
#include <cctype>
#include <cstring>

extern "C" {
#include <lauxlib.h>
#include <lua.h>
#include <lualib.h>
}

// Só existe um ScriptSystem ativo por vez; as funções C do Lua acessam o contexto por aqui.
static ScriptSystem* G = nullptr;
static const char* const kEntityMT = "Hollow.Entity";

// ---------------------------------------------------------------- utilidades

static uint32_t packColor(float r, float g, float b) {
    auto c = [](float v) { return (uint32_t)(std::max(0.0f, std::min(1.0f, v)) * 255.0f + 0.5f); };
    return 0xFF000000u | (c(r) << 16) | (c(g) << 8) | c(b);
}

static void pushEntity(lua_State* L, int id) {
    lua_newtable(L);
    lua_pushinteger(L, id);
    lua_setfield(L, -2, "id");
    luaL_setmetatable(L, kEntityMT);
}

static int idOf(lua_State* L, int idx) {
    luaL_checktype(L, idx, LUA_TTABLE);
    lua_getfield(L, idx, "id");
    int id = (int)lua_tointeger(L, -1);
    lua_pop(L, 1);
    return id;
}

// Obs.: luaL_error faz longjmp; por isso estas funções não mantêm objetos C++ com destrutor vivos.
static Entity* self(lua_State* L, int idx = 1) {
    int id = idOf(L, idx);
    Entity* e = G->scene->find(id);
    if (!e) luaL_error(L, "a entidade %d nao existe mais", id);
    return e;
}

static float num(lua_State* L, int i) { return (float)luaL_checknumber(L, i); }

static void pushVec3(lua_State* L, const Vec3& v) {
    lua_pushnumber(L, v.x);
    lua_pushnumber(L, v.y);
    lua_pushnumber(L, v.z);
}

// ---------------------------------------------------------------- métodos da entidade

template <Vec3 Transform::*M>
static int tGet(lua_State* L) {
    Entity* e = self(L);
    pushVec3(L, e->t.*M);
    return 3;
}
template <Vec3 Transform::*M>
static int tSet(lua_State* L) {
    Entity* e = self(L);
    e->t.*M = Vec3(num(L, 2), num(L, 3), num(L, 4));
    return 0;
}
template <Vec3 Transform::*M>
static int tAdd(lua_State* L) {
    Entity* e = self(L);
    e->t.*M += Vec3(num(L, 2), num(L, 3), num(L, 4));
    return 0;
}

static int e_set_scale(lua_State* L) {   // set_scale(s) ou set_scale(x, y, z)
    Entity* e = self(L);
    if (lua_gettop(L) == 2) {
        float s = num(L, 2);
        e->t.scale = Vec3(s, s, s);
    } else {
        e->t.scale = Vec3(num(L, 2), num(L, 3), num(L, 4));
    }
    return 0;
}

static int e_world_position(lua_State* L) {
    Entity* e = self(L);
    pushVec3(L, G->scene->worldMatrix(*e).translation());
    return 3;
}

static int e_forward(lua_State* L) {   // direção "para frente" (-Z local) em coordenadas de mundo
    Entity* e = self(L);
    pushVec3(L, G->scene->worldMatrix(*e).dir(Vec3(0, 0, -1)).normalized());
    return 3;
}

static int e_set_color(lua_State* L) {   // r, g, b em 0..1
    Entity* e = self(L);
    e->color = packColor(num(L, 2), num(L, 3), num(L, 4));
    return 0;
}

static int e_set_texture(lua_State* L) {
    Entity* e = self(L);
    e->texture = lua_isnoneornil(L, 2) ? "" : luaL_checkstring(L, 2);
    return 0;
}

static int e_set_model(lua_State* L) {   // set_model("modelos/arvore.obj")
    Entity* e = self(L);
    e->model = luaL_checkstring(L, 2);
    e->mesh = MeshType::Model;
    return 0;
}

static int e_set_active(lua_State* L) {
    Entity* e = self(L);
    e->active = lua_toboolean(L, 2) != 0;
    return 0;
}

static int e_is_active(lua_State* L) {
    Entity* e = self(L);
    lua_pushboolean(L, e->active);
    return 1;
}

static int e_name(lua_State* L) {
    Entity* e = self(L);
    lua_pushstring(L, e->name.c_str());
    return 1;
}

static int e_set_intensity(lua_State* L) {
    Entity* e = self(L);
    e->light.intensity = num(L, 2);
    return 0;
}

static int e_play(lua_State* L) {
    Entity* e = self(L);
    lua_pushboolean(L, e->anim.play(luaL_checkstring(L, 2)));
    return 1;
}

static int e_stop_anim(lua_State* L) {
    Entity* e = self(L);
    e->anim.stop();
    return 0;
}

static int e_destroy(lua_State* L) {
    Entity* e = self(L);
    G->scene->queueDestroy(e->id);   // removido ao fim do frame
    return 0;
}

static int e_eq(lua_State* L) {
    lua_pushboolean(L, idOf(L, 1) == idOf(L, 2));
    return 1;
}

static const luaL_Reg kEntityMethods[] = {
    {"get_position", tGet<&Transform::pos>},   {"set_position", tSet<&Transform::pos>},
    {"translate", tAdd<&Transform::pos>},      {"get_rotation", tGet<&Transform::rot>},
    {"set_rotation", tSet<&Transform::rot>},   {"rotate", tAdd<&Transform::rot>},
    {"get_scale", tGet<&Transform::scale>},    {"set_scale", e_set_scale},
    {"get_world_position", e_world_position},  {"forward", e_forward},
    {"set_color", e_set_color},                {"set_model", e_set_model},                {"set_texture", e_set_texture},
    {"set_active", e_set_active},              {"is_active", e_is_active},
    {"name", e_name},                          {"set_intensity", e_set_intensity},
    {"play", e_play},                          {"stop_anim", e_stop_anim},
    {"destroy", e_destroy},                    {nullptr, nullptr}};

// ---------------------------------------------------------------- scene

static int s_find(lua_State* L) {
    Entity* e = G->scene->findByName(luaL_checkstring(L, 1));
    if (!e) { lua_pushnil(L); return 1; }
    pushEntity(L, e->id);
    return 1;
}

static bool meshFromName(const char* s, MeshType& out) {
    char b[16] = {0};
    for (int i = 0; s[i] && i < 15; i++) b[i] = (char)std::tolower((unsigned char)s[i]);
    if (!std::strcmp(b, "cube") || !std::strcmp(b, "cubo")) out = MeshType::Cube;
    else if (!std::strcmp(b, "plane") || !std::strcmp(b, "plano")) out = MeshType::Plane;
    else if (!std::strcmp(b, "cone")) out = MeshType::Cone;
    else if (!std::strcmp(b, "sphere") || !std::strcmp(b, "esfera")) out = MeshType::Sphere;
    else if (!std::strcmp(b, "empty") || !std::strcmp(b, "vazio")) out = MeshType::None;
    else return false;
    return true;
}

static int s_spawn(lua_State* L) {   // scene.spawn("cube", x, y, z)
    MeshType mt = MeshType::Cube;
    if (!meshFromName(luaL_checkstring(L, 1), mt)) return luaL_argerror(L, 1, "malha desconhecida (cube, plane, cone, sphere, empty)");
    Vec3 p((float)luaL_optnumber(L, 2, 0), (float)luaL_optnumber(L, 3, 0), (float)luaL_optnumber(L, 4, 0));
    Entity& e = G->scene->create("Spawn", mt, p);
    pushEntity(L, e.id);
    return 1;
}

static int s_overlaps(lua_State* L) {
    lua_pushboolean(L, G->scene->overlaps(idOf(L, 1), idOf(L, 2)));
    return 1;
}

static int s_count(lua_State* L) {
    lua_pushinteger(L, (lua_Integer)G->scene->entities.size());
    return 1;
}

static const luaL_Reg kSceneLib[] = {
    {"find", s_find}, {"spawn", s_spawn}, {"overlaps", s_overlaps}, {"count", s_count}, {nullptr, nullptr}};

// ---------------------------------------------------------------- camera (câmera do jogo)

static int c_get_position(lua_State* L) { pushVec3(L, G->scene->camera.pos); return 3; }
static int c_set_position(lua_State* L) {
    G->scene->camera.pos = Vec3(num(L, 1), num(L, 2), num(L, 3));
    return 0;
}
static int c_get_rotation(lua_State* L) {
    lua_pushnumber(L, G->scene->camera.yaw);
    lua_pushnumber(L, G->scene->camera.pitch);
    return 2;
}
static int c_set_rotation(lua_State* L) {   // yaw, pitch em graus (yaw -90 = olhando para -Z)
    Camera& c = G->scene->camera;
    c.yaw = num(L, 1);
    c.pitch = std::max(-89.0f, std::min(89.0f, num(L, 2)));
    return 0;
}
static int c_forward(lua_State* L) { pushVec3(L, G->scene->camera.front()); return 3; }
static int c_right(lua_State* L) { pushVec3(L, G->scene->camera.right()); return 3; }

static const luaL_Reg kCameraLib[] = {{"get_position", c_get_position}, {"set_position", c_set_position},
                                      {"get_rotation", c_get_rotation}, {"set_rotation", c_set_rotation},
                                      {"forward", c_forward},           {"right", c_right},
                                      {nullptr, nullptr}};

// ---------------------------------------------------------------- input / time / log

static int i_key_down(lua_State* L) {
    SDL_Scancode s = SDL_GetScancodeFromName(luaL_checkstring(L, 1));
    lua_pushboolean(L, s != SDL_SCANCODE_UNKNOWN && G->input->down(s));
    return 1;
}
static int i_key_pressed(lua_State* L) {
    SDL_Scancode s = SDL_GetScancodeFromName(luaL_checkstring(L, 1));
    lua_pushboolean(L, s != SDL_SCANCODE_UNKNOWN && G->input->pressed(s));
    return 1;
}
static int i_key_released(lua_State* L) {
    SDL_Scancode s = SDL_GetScancodeFromName(luaL_checkstring(L, 1));
    lua_pushboolean(L, s != SDL_SCANCODE_UNKNOWN && G->input->released(s));
    return 1;
}
static int i_mouse_down(lua_State* L) {   // 1 = esquerdo, 2 = meio, 3 = direito
    lua_pushboolean(L, G->input->mouseDown((int)luaL_checkinteger(L, 1)));
    return 1;
}
static int i_mouse_delta(lua_State* L) {
    lua_pushinteger(L, G->input->enabled ? G->input->dx : 0);
    lua_pushinteger(L, G->input->enabled ? G->input->dy : 0);
    return 2;
}
static int i_mouse_position(lua_State* L) {   // posição em pixels dentro da área do jogo (toque = mouse no Android)
    lua_pushinteger(L, G->input->mx);
    lua_pushinteger(L, G->input->my);
    return 2;
}
static int i_screen_size(lua_State* L) {
    lua_pushinteger(L, G->input->screenW);
    lua_pushinteger(L, G->input->screenH);
    return 2;
}
static int i_lock_mouse(lua_State* L) {   // Esc libera o mouse
    SDL_SetRelativeMouseMode(lua_toboolean(L, 1) ? SDL_TRUE : SDL_FALSE);
    return 0;
}

static const luaL_Reg kInputLib[] = {{"key_down", i_key_down},       {"key_pressed", i_key_pressed},
                                     {"key_released", i_key_released}, {"mouse_down", i_mouse_down},
                                     {"mouse_delta", i_mouse_delta}, {"mouse_position", i_mouse_position}, {"screen_size", i_screen_size}, {"lock_mouse", i_lock_mouse},
                                     {nullptr, nullptr}};

static int t_delta(lua_State* L) { lua_pushnumber(L, G->dt); return 1; }
static int t_elapsed(lua_State* L) { lua_pushnumber(L, G->elapsed); return 1; }
static const luaL_Reg kTimeLib[] = {{"delta", t_delta}, {"elapsed", t_elapsed}, {nullptr, nullptr}};

static int l_log(lua_State* L) {
    int n = lua_gettop(L);
    std::string msg;
    for (int i = 1; i <= n; i++) {
        size_t len = 0;
        const char* s = luaL_tolstring(L, i, &len);
        if (i > 1) msg += ' ';
        msg.append(s, len);
        lua_pop(L, 1);
    }
    G->console->log(msg);
    return 0;
}

// Protege o editor contra loops infinitos: aborta o script depois de ~20 milhões de instruções
static void hook(lua_State* L, lua_Debug*) {
    if (++G->hookTicks > 20) luaL_error(L, "script demorou demais (loop infinito?)");
}

// ---------------------------------------------------------------- ScriptSystem

bool ScriptSystem::start(Scene* s, Input* in, Console* con) {
    stop();
    scene = s; input = in; console = con;
    dt = 0; elapsed = 0;
    G = this;

    L_ = luaL_newstate();
    if (!L_) { console->error("[lua] sem memória para criar o estado Lua"); return false; }
    lua_State* L = L_;

    // Só bibliotecas puras: nada de io, os, package ou debug (scripts não mexem em arquivos)
    luaL_requiref(L, "_G", luaopen_base, 1);     lua_pop(L, 1);
    luaL_requiref(L, "math", luaopen_math, 1);   lua_pop(L, 1);
    luaL_requiref(L, "string", luaopen_string, 1); lua_pop(L, 1);
    luaL_requiref(L, "table", luaopen_table, 1); lua_pop(L, 1);
    lua_pushnil(L); lua_setglobal(L, "dofile");
    lua_pushnil(L); lua_setglobal(L, "loadfile");

    luaL_newmetatable(L, kEntityMT);
    luaL_newlib(L, kEntityMethods);
    lua_setfield(L, -2, "__index");
    lua_pushcfunction(L, e_eq);
    lua_setfield(L, -2, "__eq");
    lua_pop(L, 1);

    luaL_newlib(L, kSceneLib);  lua_setglobal(L, "scene");
    luaL_newlib(L, kCameraLib); lua_setglobal(L, "camera");
    luaL_newlib(L, kInputLib);  lua_setglobal(L, "input");
    luaL_newlib(L, kTimeLib);   lua_setglobal(L, "time");
    lua_pushcfunction(L, l_log); lua_setglobal(L, "log");
    lua_pushcfunction(L, l_log); lua_setglobal(L, "print");
    lua_sethook(L, hook, LUA_MASKCOUNT, 1000000);

    // Carrega todos os scripts primeiro e só depois dispara on_start
    std::vector<int> ids;
    for (const Entity& e : scene->entities)
        if (!e.script.empty() && scene->activeInHierarchy(e)) ids.push_back(e.id);
    for (int id : ids)
        if (const Entity* e = scene->find(id)) loadInstance(*e);
    for (Instance& inst : instances_)
        if (!inst.failed) call(inst, "on_start", false);

    console->log("[lua] " + std::to_string(instances_.size()) + " script(s) carregado(s)");
    return true;
}

bool ScriptSystem::loadInstance(const Entity& e) {
    lua_State* L = L_;
    Instance inst;
    inst.entityId = e.id;
    inst.path = e.script;

    std::string src;
    if (!readFile(e.script, src)) { console->error("[lua] script não encontrado: " + e.script); return false; }
    if (luaL_loadbuffer(L, src.data(), src.size(), ("@" + e.script).c_str()) != LUA_OK) {
        console->error(std::string("[lua] ") + lua_tostring(L, -1));
        lua_pop(L, 1);
        return false;
    }

    // Cada instância roda num ambiente próprio (variáveis globais do script ficam por entidade)
    lua_newtable(L);                 // env
    lua_newtable(L);                 // metatabela do env
    lua_pushglobaltable(L);
    lua_setfield(L, -2, "__index");  // env herda as APIs globais
    lua_setmetatable(L, -2);
    lua_pushvalue(L, -1);
    inst.envRef = luaL_ref(L, LUA_REGISTRYINDEX);
    lua_setupvalue(L, -2, 1);        // _ENV do chunk = env

    hookTicks = 0;
    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        console->error(std::string("[lua] ") + lua_tostring(L, -1));
        lua_pop(L, 1);
        luaL_unref(L, LUA_REGISTRYINDEX, inst.envRef);
        return false;
    }
    pushEntity(L, e.id);
    inst.selfRef = luaL_ref(L, LUA_REGISTRYINDEX);
    instances_.push_back(inst);
    return true;
}

bool ScriptSystem::call(Instance& inst, const char* fn, bool withDt) {
    lua_State* L = L_;
    lua_rawgeti(L, LUA_REGISTRYINDEX, inst.envRef);
    lua_getfield(L, -1, fn);
    if (!lua_isfunction(L, -1)) { lua_pop(L, 2); return true; }   // callback é opcional
    lua_rawgeti(L, LUA_REGISTRYINDEX, inst.selfRef);
    int nargs = 1;
    if (withDt) { lua_pushnumber(L, dt); nargs = 2; }
    hookTicks = 0;
    if (lua_pcall(L, nargs, 0, 0) != LUA_OK) {
        console->error(std::string("[lua] ") + lua_tostring(L, -1));
        lua_pop(L, 2);   // mensagem de erro + env
        inst.failed = true;   // não repete o erro todo frame
        return false;
    }
    lua_pop(L, 1);   // env
    return true;
}

void ScriptSystem::update(float deltaTime) {
    if (!L_) return;
    dt = deltaTime;
    elapsed += deltaTime;
    for (Instance& inst : instances_) {
        if (inst.failed) continue;
        const Entity* e = scene->find(inst.entityId);
        if (!e || !scene->activeInHierarchy(*e)) continue;
        call(inst, "on_update", true);
    }
}

void ScriptSystem::stop() {
    if (L_) {
        lua_close(L_);
        L_ = nullptr;
        SDL_SetRelativeMouseMode(SDL_FALSE);
    }
    instances_.clear();
    if (G == this) G = nullptr;
}
