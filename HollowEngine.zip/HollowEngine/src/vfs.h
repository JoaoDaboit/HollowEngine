// vfs.h - leitura de arquivos com gancho substituível.
// No editor lê do disco. No jogo exportado o player troca o leitor por SDL_RWops, que também
// enxerga a pasta de assets dentro do APK no Android. Não depende de SDL.
#pragma once
#include <fstream>
#include <functional>
#include <sstream>
#include <string>

using FileReader = std::function<bool(const std::string&, std::string&)>;

inline FileReader& fileReader() {
    static FileReader reader;
    return reader;
}

inline bool readFile(const std::string& path, std::string& out) {
    if (fileReader()) return fileReader()(path, out);
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::ostringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}
