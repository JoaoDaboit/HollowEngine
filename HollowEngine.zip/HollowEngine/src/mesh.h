// mesh.h - primitivas procedurais (todas cabem na caixa [-0.5, 0.5]^3)
#pragma once
#include <string>
#include <vector>
#include "math3d.h"

enum class MeshType : int { Cube = 0, Plane = 1, Cone = 2, Sphere = 3, None = 4, Model = 5 };
constexpr int kMeshTypeCount = 6;
extern const char* const kMeshNames[kMeshTypeCount];   // "Cubo", "Plano", ...

// Lista de triângulos (3 vértices consecutivos = 1 triângulo), anti-horário visto de fora
struct Mesh {
    std::vector<Vec3> pos;
    std::vector<Vec2> uv;
    Vec3 half{0.5f, 0.5f, 0.5f};   // meia-extensão da caixa que envolve a malha
    size_t triCount() const { return pos.size() / 3; }
};

const Mesh& getMesh(MeshType t);
Vec3 meshHalfExtents(MeshType t);   // meia-extensão local (picking e colisão)

// Importação de modelos Wavefront .obj (v, vt, f com índices negativos e polígonos).
// O modelo é centralizado e escalado para caber em 1 unidade; a escala do objeto faz o resto.
bool loadObj(const std::string& path, Mesh& out, std::string* error = nullptr);

// Malha de uma entidade: primitiva, ou modelo importado (carregado uma vez e guardado em cache).
// Modelo que falhou ao carregar devolve malha vazia.
const Mesh& meshFor(MeshType t, const std::string& modelPath);
Vec3 meshHalfExtentsFor(MeshType t, const std::string& modelPath);
void clearModelCache();
