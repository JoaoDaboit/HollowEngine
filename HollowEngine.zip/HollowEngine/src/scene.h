// scene.h - entidades, hierarquia e (de)serialização. Não depende de SDL, ImGui nem Lua.
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "animation.h"
#include "camera.h"
#include "mesh.h"
#include "math3d.h"

enum class LightType : int { Point = 0, Directional = 1 };

struct LightComp {
    LightType type = LightType::Point;
    float intensity = 1.0f;
    Vec3 color{1, 1, 1};
};

// Entidade com componentes opcionais. Id 0 = "nenhuma" (usado em parent e seleção).
struct Entity {
    int id = 0;
    std::string name = "Objeto";
    int parent = 0;
    bool active = true;

    Transform t;

    MeshType mesh = MeshType::Cube;
    uint32_t color = 0xFF4A90E2;   // ARGB
    std::string texture;           // caminho PNG/JPG (vazio = cor sólida)
    std::string model;             // caminho de um .obj (usado quando mesh == Model)

    bool hasLight = false;
    LightComp light;

    std::string script;            // caminho de um .lua
    Animator anim;
};

struct Scene {
    std::vector<Entity> entities;
    int nextId = 1;
    Camera camera;                 // câmera do jogo (a do editor é separada)
    float ambient = 0.35f;
    uint32_t sky = 0xFFC896FF;

    // --- consulta ---
    Entity* find(int id);
    const Entity* find(int id) const;
    Entity* findByName(const std::string& name);
    bool activeInHierarchy(const Entity& e) const;
    Mat4 worldMatrix(const Entity& e) const;
    bool isDescendant(int id, int ancestor) const;

    // --- edição ---
    Entity& create(const std::string& name, MeshType mesh, const Vec3& pos = Vec3());
    int duplicate(int id);
    bool setParent(int id, int parentId);   // mantém a posição de mundo
    void destroy(int id);                   // remove também os filhos
    void queueDestroy(int id) { pending.push_back(id); }
    void flushDestroy();

    // Sobreposição de caixas alinhadas ao mundo (colisão simples para scripts)
    bool overlaps(int a, int b) const;

    void setupDefault();                    // cena inicial de exemplo
    void clear();

    bool save(const std::string& path) const;
    bool load(const std::string& path);

    std::vector<int> pending;
};
