// renderer.h - rasterizador 3D por software sobre SDL_RenderGeometry
//
// Pipeline: transforma malhas -> descarta faces de costas -> ilumina por triângulo ->
// corta no plano near -> projeta -> ordena TODOS os triângulos da cena (painter's algorithm)
// -> envia em lotes agrupados por textura.
#pragma once
#include "sdl_compat.h"
#include <string>
#include <unordered_map>
#include <vector>
#include "camera.h"
#include "scene.h"

class Renderer {
public:
    explicit Renderer(SDL_Renderer* r) : r_(r) {}
    ~Renderer() { clearTextures(); }
    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    // Texturas carregadas sob demanda e guardadas em cache pelo caminho
    SDL_Texture* texture(const std::string& path);
    void clearTextures();

    // Tudo que for desenhado entre begin() e end() fica restrito ao retângulo do viewport
    void begin(const Camera& cam, int x, int y, int w, int h, uint32_t skyArgb);
    void end();
    const View& view() const { return view_; }

    void drawScene(const Scene& scene);

    // Auxiliares de debug / editor (coordenadas de mundo)
    void drawGrid(int extent = 10);
    void line(const Vec3& a, const Vec3& b, uint32_t argb, float thickness = 1.0f);
    void box(const Mat4& world, const Vec3& half, uint32_t argb);
    void ring(const Vec3& center, const Vec3& u, const Vec3& v, float radius, uint32_t argb,
              float thickness, int segments = 32);
    void marker(const Vec3& p, uint32_t argb, int halfSize);

private:
    struct Tri {
        SDL_Vertex v[3];
        SDL_Texture* tex;
        float depth;
    };
    struct CV {   // vértice durante o clipping
        Vec3 p;
        Vec2 uv;
    };

    void lineScreen(const Vec2& a, const Vec2& b, float thickness, uint32_t argb);
    void pushClipped(const CV in[3], const SDL_Color& col, SDL_Texture* tex, float depth);

    SDL_Renderer* r_;
    View view_;
    std::unordered_map<std::string, SDL_Texture*> tex_;
    std::vector<Tri> tris_;
    std::vector<SDL_Vertex> batch_;
};
