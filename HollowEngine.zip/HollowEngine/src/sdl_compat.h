// sdl_compat.h - inclui SDL e SDL_image tanto no layout <SDL2/...> (Linux/Windows) quanto no <SDL.h> (projeto Android)
#pragma once
#if __has_include(<SDL2/SDL.h>)
#include <SDL2/SDL.h>
#else
#include <SDL.h>
#endif
#if __has_include(<SDL2/SDL_image.h>)
#include <SDL2/SDL_image.h>
#else
#include <SDL_image.h>
#endif
