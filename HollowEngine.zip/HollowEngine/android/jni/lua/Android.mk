# Compila o Lua 5.4 como biblioteca estática. Coloque o código-fonte oficial em app/jni/lua/src/.
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := lua
LOCAL_C_INCLUDES := $(LOCAL_PATH)/src
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/src
LUA_FILES := lapi lauxlib lbaselib lcode lcorolib lctype ldblib ldebug ldo ldump lfunc lgc linit liolib llex \
             lmathlib lmem loadlib lobject lopcodes loslib lparser lstate lstring lstrlib ltable ltablib ltm \
             lundump lutf8lib lvm lzio
LOCAL_SRC_FILES := $(addprefix src/,$(addsuffix .c,$(LUA_FILES)))
include $(BUILD_STATIC_LIBRARY)
