APP_ABI := arm64-v8a armeabi-v7a x86_64
APP_PLATFORM := android-21
APP_STL := c++_shared
APP_CPPFLAGS := -std=c++17 -frtti -fexceptions
