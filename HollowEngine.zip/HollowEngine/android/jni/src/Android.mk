# Módulo "main" do jogo (o SDLActivity carrega libmain.so).
# Copie para app/jni/src/ do projeto Android junto com src/*.cpp e src/*.h da engine
# (mesh, animation, scene, renderer, script, player + cabeçalhos). NÃO copie editor.cpp nem main.cpp.
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := main
LOCAL_C_INCLUDES := $(LOCAL_PATH)/../SDL/include $(LOCAL_PATH)/../SDL_image/include
LOCAL_SRC_FILES := mesh.cpp animation.cpp scene.cpp renderer.cpp script.cpp player.cpp
LOCAL_SHARED_LIBRARIES := SDL2 SDL2_image
LOCAL_STATIC_LIBRARIES := lua
LOCAL_LDLIBS := -lGLESv1_CM -lGLESv2 -llog
include $(BUILD_SHARED_LIBRARY)
