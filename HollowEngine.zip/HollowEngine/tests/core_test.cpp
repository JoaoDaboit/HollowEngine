// Testes do núcleo (sem SDL / ImGui / Lua). Rode com: make test
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include "../src/scene.h"

static int failures = 0;
#define CHECK(cond)                                                              \
    do {                                                                         \
        if (!(cond)) { std::printf("FALHOU %s:%d  %s\n", __FILE__, __LINE__, #cond); failures++; } \
    } while (0)
static bool near(float a, float b, float eps = 1e-3f) { return std::fabs(a - b) < eps; }

static void testMath() {
    Transform t;
    t.pos = Vec3(1, 2, 3); t.rot = Vec3(30, 45, 60); t.scale = Vec3(2, 1, 0.5f);
    Mat4 m = t.matrix();
    Mat4 id = m * m.inverseAffine();
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) CHECK(near(id.m[i][j], i == j ? 1.0f : 0.0f));

    // Mesma convenção do Engine.cpp original (X, depois Y, depois Z)
    Vec3 p(1, 0, 0);
    Mat4 r = Mat4::trs(Vec3(), Vec3(0, 90, 0), Vec3(1, 1, 1));
    Vec3 q = r.point(p);
    CHECK(near(q.x, 0) && near(q.z, -1));

    float th;
    CHECK(rayBox(Vec3(0, 0, 5), Vec3(0, 0, -1), Vec3(0.5f, 0.5f, 0.5f), th) && near(th, 4.5f));
    CHECK(!rayBox(Vec3(2, 0, 5), Vec3(0, 0, -1), Vec3(0.5f, 0.5f, 0.5f), th));
}

static void testCamera() {
    Camera c;
    View v = c.view(800, 600);
    Vec3 target(1, 1, -2);
    Vec2 s;
    CHECK(v.project(target, s));
    Vec3 o, d;
    c.ray(s, 800, 600, o, d);
    Vec3 toT = (target - o).normalized();
    CHECK(near(toT.dot(d), 1.0f, 1e-4f));
    CHECK(!v.project(c.pos - c.front() * 3.0f, s));   // atrás da câmera
}

static void testMeshWinding() {
    for (int t = 0; t < kMeshTypeCount; t++) {
        const Mesh& m = getMesh((MeshType)t);
        CHECK(m.pos.size() == m.uv.size() && m.pos.size() % 3 == 0);
        int up = 0, down = 0;
        for (size_t i = 0; i < m.triCount(); i++) {
            Vec3 a = m.pos[i * 3], b = m.pos[i * 3 + 1], c = m.pos[i * 3 + 2];
            Vec3 n = (b - a).cross(c - a);
            if (n.length() < 1e-9f) continue;   // polos da esfera
            n = n.normalized();
            Vec3 centro = (a + b + c) * (1.0f / 3.0f);
            if ((MeshType)t == MeshType::Plane) { (n.y > 0 ? up : down)++; continue; }
            CHECK(n.dot(centro) > 0);   // normal aponta para fora
        }
        if ((MeshType)t == MeshType::Plane) CHECK(up > 0 && up == down);
    }
}

static void testAnimation() {
    AnimClip c;
    c.duration = 2;
    AnimTrack* tr = c.track(AnimChannel::Position, true);
    tr->setKey(1.0f, Vec3(10, 0, 0));
    tr->setKey(0.0f, Vec3(0, 0, 0));          // fora de ordem de propósito
    tr->setKey(1.0f, Vec3(20, 0, 0));         // substitui
    CHECK(tr->keys.size() == 2 && near(tr->keys[1].value.x, 20));

    Transform t;
    c.sample(0.5f, t);
    CHECK(near(t.pos.x, 10));
    tr->keys[0].interp = Interp::Step;
    c.sample(0.5f, t);
    CHECK(near(t.pos.x, 0));
    tr->keys[0].interp = Interp::Smooth;
    c.sample(0.25f, t);
    CHECK(t.pos.x < 5.0f);                    // smoothstep começa devagar

    Animator an;
    an.clips.push_back(c);
    an.clips[0].name = "A";
    an.clips[0].loop = false;
    CHECK(an.play("A") && an.playing);
    an.update(5.0f, t);
    CHECK(!an.playing && near(t.pos.x, 20));
    CHECK(!an.play("inexistente"));
}

static void testScene() {
    Scene s;
    s.setupDefault();
    size_t n = s.entities.size();
    CHECK(n >= 5);

    CHECK(s.save("/tmp/hollow_test.hscene"));
    Scene l;
    CHECK(l.load("/tmp/hollow_test.hscene"));
    CHECK(l.entities.size() == n);
    Entity* esf = l.findByName("Esfera");
    CHECK(esf && esf->anim.clips.size() == 1 && esf->anim.clips[0].tracks[0].keys.size() == 3);
    CHECK(esf && esf->anim.autoplay == "Flutuar");
    Entity* sol = l.findByName("Sol");
    CHECK(sol && sol->hasLight && sol->light.type == LightType::Directional);
    CHECK(l.nextId == s.nextId);
    CHECK(!l.load("/tmp/nao_existe.hscene"));

    // hierarquia: setParent preserva a posição de mundo
    Scene h;
    Entity& pai = h.create("Pai", MeshType::Cube, Vec3(10, 0, 0));
    int paiId = pai.id;
    pai.t.rot = Vec3(0, 90, 0);
    Entity& filho = h.create("Filho", MeshType::Cube, Vec3(10, 0, -5));
    int filhoId = filho.id;
    CHECK(h.setParent(filhoId, paiId));
    Vec3 w = h.worldMatrix(*h.find(filhoId)).translation();
    CHECK(near(w.x, 10) && near(w.z, -5));
    CHECK(!h.setParent(paiId, filhoId));      // ciclo proibido
    CHECK(!h.setParent(paiId, paiId));

    h.destroy(paiId);
    CHECK(h.entities.empty());                // filho morre junto

    // colisão simples
    Scene c;
    int a = c.create("A", MeshType::Cube, Vec3(0, 0, 0)).id;
    int b = c.create("B", MeshType::Cube, Vec3(0.9f, 0, 0)).id;
    int d = c.create("C", MeshType::Cube, Vec3(3, 0, 0)).id;
    CHECK(c.overlaps(a, b));
    CHECK(!c.overlaps(a, d));
    c.queueDestroy(b);
    c.flushDestroy();
    CHECK(c.find(b) == nullptr && c.entities.size() == 2);

    int dup = c.duplicate(a);
    CHECK(dup != 0 && c.find(dup) && c.entities.size() == 3);
}

static void testObj() {
    {
        std::ofstream f("/tmp/hollow_quad.obj");
        f << "# quadrado com uv e índices negativos\nv 0 0 0\nv 4 0 0\nv 4 2 0\nv 0 2 0\n"
          << "vt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nf -4/-4 -3/-3 -2/-2 -1/-1\n";
    }
    Mesh m;
    std::string err;
    CHECK(loadObj("/tmp/hollow_quad.obj", m, &err));
    CHECK(m.triCount() == 2);                       // quad -> 2 triângulos
    CHECK(near(m.half.x, 0.5f) && near(m.half.y, 0.25f));   // normalizado: maior lado = 1
    CHECK(near(m.uv[1].x, 1.0f) && near(m.uv[1].y, 1.0f));  // v invertido (1 - 0)
    CHECK(!loadObj("/tmp/nao_existe.obj", m, &err));

    Entity e;
    e.mesh = MeshType::Model;
    e.model = "/tmp/hollow_quad.obj";
    CHECK(meshFor(e.mesh, e.model).triCount() == 2);
    CHECK(near(meshHalfExtentsFor(e.mesh, e.model).y, 0.25f));
    CHECK(meshFor(MeshType::Model, "/tmp/nao_existe.obj").pos.empty());

    Scene s;
    Entity& n = s.create("Modelo", MeshType::Model);
    n.model = "/tmp/hollow_quad.obj";
    CHECK(s.save("/tmp/hollow_obj.hscene"));
    Scene l;
    CHECK(l.load("/tmp/hollow_obj.hscene") && l.entities[0].model == "/tmp/hollow_quad.obj");
}

int main() {
    testMath();
    testCamera();
    testMeshWinding();
    testAnimation();
    testScene();
    testObj();
    if (failures == 0) std::printf("Todos os testes passaram.\n");
    return failures == 0 ? 0 : 1;
}
