# Exporting a game

Exporting has two parts: the editor packages your **content** (scene, scripts, textures, models), and a
small **player** program runs it. The player is the engine without the editor or ImGui.

```
MyGame/
  hollow_player(.exe)   <- the runtime
  data/
    game.hscene         <- your scene
    scripts/ textures/ models/ ...   <- everything the scene references, same relative paths
```

## 1. Export the content (all platforms)

0. Sounds are only mentioned inside Lua scripts, so the editor cannot see them: put your `.wav` files in an `audio/` folder next to the Makefile and the whole folder is copied to `data/audio/`.
1. Keep every asset (scripts, textures, `.obj` files) **inside the project folder** and reference it by relative path
   (the editor's file browser does this automatically).
2. In the editor: `File > Export game...`, choose a folder such as `export/MyGame`.
3. Check the Console: it lists assets that were missing or outside the project.

## 2. Windows (.exe)

Build on Windows with MSYS2 (recommended, simplest):

```bash
# MINGW64 shell
pacman -S --needed mingw-w64-x86_64-toolchain mingw-w64-x86_64-SDL2 mingw-w64-x86_64-SDL2_image \
          mingw-w64-x86_64-lua mingw-w64-x86_64-pkg-config make git
make player LUA_PKG=lua            # produces hollow_player.exe
tools/package_windows.sh export/MyGame
```

`export/MyGame` now contains `hollow_player.exe`, the required DLLs and `data/`; zip the folder and share it.
To hide the console window, add `-mwindows` to `LDLIBS` when building the player.

Cross-compiling from Linux with `x86_64-w64-mingw32-g++` also works if you have mingw builds of SDL2, SDL2_image and Lua;
set `CXX=x86_64-w64-mingw32-g++` and point `pkg-config` at those libraries.

## 3. Linux

```bash
make player
cp hollow_player export/MyGame/     # or let the editor copy it: keep hollow_player next to the editor when exporting
```

Run `export/MyGame/hollow_player`. Users need SDL2, SDL2_image and Lua 5.4 installed, or ship them yourself.

## 4. Android (.apk)

Android uses SDL's Gradle template and the Android NDK. This path has **not been tested** by the authors; expect to
adjust versions.

**Tools:** Android Studio (SDK, NDK, JDK 17), plus the source of SDL2 (>= 2.0.18), SDL2_image and Lua 5.4.

1. Copy SDL2's `android-project/` folder to a new folder, e.g. `MyGame-android/`.
2. Put the sources under `MyGame-android/app/jni/`:
   - `SDL/` – the SDL2 source tree (needs `SDL/Android.mk`)
   - `SDL_image/` – the SDL2_image source tree; run its `external/download.sh` to fetch libpng/libjpeg
   - `lua/` – copy `android/jni/lua/Android.mk` from this repo and the official Lua sources into `lua/src/`
   - `src/` – copy `android/jni/src/Android.mk` plus `mesh`, `animation`, `scene`, `renderer`, `script`, `player` (`.cpp`)
     and all headers from this repo's `src/` (not `editor.cpp`, not `main.cpp`)
   - replace `app/jni/Application.mk` with `android/jni/Application.mk`
3. Copy the contents of the exported `data/` folder into `MyGame-android/app/src/main/assets/`
   (so `game.hscene` sits directly in `assets/`).
4. Set your package name and app name in `app/build.gradle` and `app/src/main/res/values/strings.xml`.
   Optional: set `android:screenOrientation="landscape"` in `AndroidManifest.xml`.
5. Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.
   Install with `adb install app-debug.apk`.
6. For release, create a keystore and sign (`assembleRelease` + `apksigner`); Google Play requires an AAB (`bundleRelease`).

**Touch input:** Android has no keyboard by default. SDL turns touches into mouse events, so scripts can use
`input.mouse_down(1)` (finger down), `input.mouse_position()` and `input.screen_size()`:

```lua
function on_update(self, dt)
  if input.mouse_down(1) then
    local x = input.mouse_position()
    local w = input.screen_size()
    local dir = (x < w / 2) and -1 or 1        -- left half of the screen moves left, right half moves right
    self:translate(dir * 4 * dt, 0, 0)
  end
end
```

Scripts that rely on `input.key_down` will not react on a phone without a keyboard.

## What is not included

- The `.exe` and `.apk` themselves: they must be built on your machine with the tools above.
- App icons/splash screens, and store packaging beyond what the Android template provides.
