-- Exemplo de áudio: aperte Space para tocar um som neste objeto (ele sai da posição do objeto).
-- Coloque seus .wav na pasta audio/ ao lado do Makefile (ela vai junto na exportação).
function on_start(self)
  log("aperte Space para ouvir o beep")
end

function on_update(self, dt)
  if input.key_pressed("Space") then
    self:play_sound("audio/beep.wav", 1.0)
  end
end
