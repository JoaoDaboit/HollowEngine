-- Gira o objeto em volta do eixo Y.
-- Variáveis globais do script ficam guardadas por objeto.
speed = 90   -- graus por segundo

function on_update(self, dt)
  self:rotate(0, speed * dt, 0)
end
