-- Movimento com WASD e câmera que segue o objeto.
-- Funciona só em modo Play, com o mouse sobre o Viewport.
local speed = 5

function on_start(self)
  log("jogador pronto: " .. self:name())
end

function on_update(self, dt)
  local dx, dz = 0, 0
  if input.key_down("W") then dz = dz - 1 end
  if input.key_down("S") then dz = dz + 1 end
  if input.key_down("A") then dx = dx - 1 end
  if input.key_down("D") then dx = dx + 1 end
  self:translate(dx * speed * dt, 0, dz * speed * dt)

  -- bate no cubo? muda de cor
  local cubo = scene.find("Cubo")
  if cubo and scene.overlaps(self, cubo) then
    self:set_color(1, 0.3, 0.3)
  else
    self:set_color(0.95, 0.8, 0.3)
  end

  local x, y, z = self:get_world_position()
  camera.set_position(x, y + 4, z + 8)
  camera.set_rotation(-90, -25)
end
