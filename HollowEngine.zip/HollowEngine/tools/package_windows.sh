#!/usr/bin/env bash
# Rode no shell MINGW64 do MSYS2, depois de 'make player'.
# Uso: tools/package_windows.sh export/MeuJogo
# Copia hollow_player.exe e as DLLs do MinGW de que ele depende para a pasta exportada.
set -euo pipefail
DEST="${1:?uso: tools/package_windows.sh <pasta exportada>}"
[ -f hollow_player.exe ] || { echo "hollow_player.exe não existe: rode 'make player' primeiro."; exit 1; }
[ -d "$DEST/data" ] || { echo "'$DEST/data' não existe: use Arquivo > Exportar jogo no editor primeiro."; exit 1; }
cp hollow_player.exe "$DEST/"
ldd hollow_player.exe | awk '/\/(mingw64|ucrt64|clang64)\// {print $3}' | sort -u | while read -r dll; do
  cp "$dll" "$DEST/"
done
echo "Pronto: execute $DEST/hollow_player.exe (leve a pasta inteira para outro PC)."
