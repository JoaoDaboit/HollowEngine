# HollowEngine

Engine 3D com editor, feita em C++17 sobre SDL2 + Dear ImGui (como o `Engine.cpp` original), agora com
cena/entidades/hierarquia, animação por keyframes, scripts Lua, modo Play e cenas salvas em arquivo.

**Dependências:** SDL2, SDL2_image, Dear ImGui (pasta `imgui/` ao lado do Makefile) e Lua 5.4.
Nenhuma outra biblioteca nem programa externo (o `zenity` foi removido; há um navegador de arquivos embutido).

## Compilar

```
sudo apt install libsdl2-dev libsdl2-image-dev liblua5.4-dev   # Debian/Ubuntu
make            # gera ./hollow
make test       # testes do núcleo (sem SDL/ImGui/Lua)
./hollow
```
Em Arch/Fedora o pacote do pkg-config é `lua`: `make LUA_PKG=lua`.

## Estrutura

| Arquivo | Função |
|---|---|
| `src/math3d.h`, `camera.h` | Vec/Mat4, transformações, câmera, projeção, raio |
| `src/mesh.*` | Cubo, plano, cone, esfera (com UVs corretos) |
| `src/animation.*` | Clips, faixas de keyframes, Animator |
| `src/scene.*` | Entidades, hierarquia pai/filho, salvar/abrir `.hscene` |
| `src/renderer.*` | Rasterizador: culling, luz por triângulo, clipping no near, ordenação global, lotes por textura |
| `src/audio.*` | Mixer de áudio (WAV) sobre o SDL2 |
| `src/script.*` | Lua (um ambiente por objeto) |
| `src/editor.*` | Painéis, gizmos, seleção por raio, timeline, Play/Stop |
| `src/main.cpp` | Janela e laço principal |

## Editor

- **Viewport:** botão direito (ou Shift) + mouse olha; WASD move; Space/Ctrl sobe/desce; roda dá zoom. Clique seleciona (raio contra a caixa do objeto). Gizmos: Mover / Escalar / Rotacionar.
- **Hierarquia:** arraste um objeto sobre outro para criar pai/filho; solte na área vazia para soltar do pai. Botão direito: duplicar/deletar. `Delete` apaga o selecionado.
- **Inspetor:** transform, malha, cor, textura, luz (pontual/direcional), script, animator.
- **Animação:** crie um clip, posicione o objeto, escolha o tempo e clique em *Gravar keyframe*. Arraste no timeline para ver a pose; *Restaurar pose* volta ao estado original. Interpolação: Linear, Degrau, Suave. *Tocar ao iniciar* define o clip automático no Play.
- **Play / Pausar / Parar:** Play guarda uma cópia da cena; Parar restaura. Nada que acontece no Play é salvo.
- Luz direcional aponta para a frente (-Z) do objeto: gire-o para mirar.

## Lua

Cada objeto pode ter um `.lua`. Callbacks opcionais: `on_start(self)` e `on_update(self, dt)`.
Variáveis globais do script ficam por objeto. Erros aparecem no Console (o script com erro é desativado).
Bibliotecas disponíveis: `math`, `string`, `table` (sem `io`/`os`). Loops infinitos são interrompidos.

**self (objeto):** `get_position() / set_position(x,y,z) / translate(dx,dy,dz)`, o mesmo para `rotation` (graus; `rotate`) e `get_scale() / set_scale(s | x,y,z)`,
`get_world_position()`, `forward()`, `set_color(r,g,b)` (0..1), `set_texture(path)`, `set_active(bool)`, `is_active()`, `name()`,
`set_intensity(v)` (luz), `play("clip")`, `stop_anim()`, `destroy()`.

**scene:** `find(nome)` (retorna objeto ou nil), `spawn("cube"|"plane"|"cone"|"sphere"|"empty", x,y,z)`, `overlaps(a,b)`, `count()`.

**camera** (câmera do jogo): `get_position/set_position(x,y,z)`, `get_rotation/set_rotation(yaw,pitch)`, `forward()`, `right()`.

**input:** `key_down("W")`, `key_pressed(...)`, `key_released(...)` (nomes do SDL: "W", "Space", "Left Shift", "Up", "Return"),
`mouse_down(1|2|3)`, `mouse_delta()`, `lock_mouse(bool)` (Esc libera). **time:** `delta()`, `elapsed()`. **log(...)**.

**audio:** `play("audio/x.wav" [, volume=1 [, loop=false [, pan=0]]])` devolve o id da voz (ou `nil` se falhar), `play_at(caminho, x,y,z [, volume [, loop]])`,
`stop(id)`, `stop_all()`, `is_playing(id)`, `set_volume(id, v)`, `set_pan(id, p)` (-1 esquerda .. 1 direita), `master_volume([v])`.
Também existe `self:play_sound(caminho [, volume [, loop]])`, que toca na posição do objeto.

## Áudio

Mixer próprio sobre o SDL2 (nenhuma dependência nova). Formato: **WAV** (o que o `SDL_LoadWAV` aceitar; PCM 16 bits é o mais seguro), mono ou estéreo, qualquer taxa: é convertido ao carregar. Até 32 sons ao mesmo tempo.
Ponha os arquivos na pasta `audio/` ao lado do Makefile: ela é copiada inteira em `Arquivo > Exportar jogo`. Os sons param quando você aperta Parar. Sem placa de som o jogo roda mesmo assim e o Console mostra o aviso.
`play_at`/`play_sound` calculam volume (cai com a distância até a câmera) e pan **uma vez**, na hora de tocar. Exemplo: `scripts/som_exemplo.lua`.

```lua
local musica = audio.play("audio/fundo.wav", 0.5, true)   -- música em loop
audio.play("audio/pulo.wav")                              -- efeito
audio.stop(musica)
```

## Importar modelos (.obj)

`Entidade > Importar modelo (.obj)...` cria um objeto com o modelo; ou escolha a malha "Modelo" no Inspetor e aponte o arquivo. O leitor é próprio (v, vt, f, índices negativos, polígonos). O modelo é centralizado e escalado para 1 unidade. Textura: defina em "Textura" (o .mtl é ignorado). Pelo Lua: `self:set_model("modelos/arvore.obj")`. Modelos com mais de ~20 mil triângulos ficam pesados neste rasterizador.

## Formato .hscene

Texto simples, uma instrução por linha (`entity`, `name`, `parent`, `transform`, `mesh`, `color`, `texture`, `light`, `script`, `clip`, `track`, `key`, `end`).
Dá para editar à mão e versionar no git.

## Mudanças em relação ao Engine.cpp

- Um arquivo de 1880 linhas virou módulos; o núcleo (cena, animação, malhas) não depende de SDL/ImGui/Lua e tem testes.
- Entidades com componentes e hierarquia (antes só `Cube` solto); limite fixo de 100 objetos removido.
- Renderização: todos os triângulos da cena são ordenados juntos (antes: por objeto), clipping real no plano near, UVs de verdade e malhas subdivididas para a luz e a textura ficarem melhores; várias luzes.
- Seleção por raio e gizmos que seguem o mouse em unidades de mundo exatas.
- Removidos: mapas normal/roughness (nunca eram usados no cálculo), texturas de ícones e de grade não usadas e a chamada ao `zenity`.

## Limites conhecidos

Ainda é um rasterizador por software com ordenação (painter's algorithm): objetos que se interpenetram podem ter pequenos erros, e a textura não tem correção de perspectiva. Não há física. Áudio: só WAV (sem OGG/MP3) e o som posicional não acompanha objetos em movimento.
